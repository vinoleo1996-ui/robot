# Interaction State Machine (MVP)

from __future__ import annotations

import logging
from enum import Enum, auto
from time import monotonic
from typing import Any

logger = logging.getLogger(__name__)


class InteractionState(Enum):
    """Core interaction states per SDD §3.2."""

    IDLE = auto()
    NOTICED_HUMAN = auto()
    MUTUAL_ATTENTION = auto()
    ENGAGING = auto()
    ONGOING_INTERACTION = auto()
    RECOVERY = auto()
    SAFETY_OVERRIDE = auto()


class InteractionStateMachine:
    """Finite state machine governing high-level robot interaction mode.

    Transitions:
        IDLE ──(human noticed)──► NOTICED_HUMAN
        NOTICED_HUMAN ──(mutual attention)──► MUTUAL_ATTENTION
        MUTUAL_ATTENTION ──(engagement bid)──► ENGAGING
        ENGAGING ──(interaction started)──► ONGOING_INTERACTION
        NOTICED_HUMAN / MUTUAL_ATTENTION / ENGAGING ──(attention lost)──► RECOVERY / IDLE
        ONGOING_INTERACTION ──(finished/timeout)──► RECOVERY
        RECOVERY ──(cooldown elapsed)──► IDLE
        ANY ──(P0 safety)──► SAFETY_OVERRIDE
        SAFETY_OVERRIDE ──(resolved)──► RECOVERY

    The state machine is intentionally lightweight — it carries no
    business logic, only state + transition timestamps. Consumers
    query ``current_state`` to modulate pipeline behaviour.
    """

    TIMEOUT_NOTICED_S = 5.0
    TIMEOUT_MUTUAL_ATTENTION_S = 6.0
    TIMEOUT_ENGAGING_S = 8.0
    TIMEOUT_ONGOING_S = 30.0
    TIMEOUT_RECOVERY_S = 3.0
    TIMEOUT_SAFETY_S = 10.0

    def __init__(self) -> None:
        self._state = InteractionState.IDLE
        self._entered_at = monotonic()
        self._transition_count = 0
        self._previous_state: InteractionState | None = None
        self._current_target_id: str | None = None
        self._last_reason: str | None = None

    # ── Properties ──────────────────────────────────────────────

    @property
    def current_state(self) -> InteractionState:
        return self._state

    @property
    def time_in_state_s(self) -> float:
        return monotonic() - self._entered_at

    @property
    def transition_count(self) -> int:
        return self._transition_count

    @property
    def current_target_id(self) -> str | None:
        return self._current_target_id

    # ── Transitions ─────────────────────────────────────────────

    def on_notice_human(self, *, target_id: str | None = None, reason: str = "notice_human") -> InteractionState:
        if self._state in {InteractionState.IDLE, InteractionState.RECOVERY}:
            self._transition(InteractionState.NOTICED_HUMAN, target_id=target_id, reason=reason)
        elif self._state == InteractionState.NOTICED_HUMAN:
            self._refresh(target_id=target_id, reason=reason)
        return self._state

    def on_mutual_attention(
        self,
        *,
        target_id: str | None = None,
        reason: str = "mutual_attention",
    ) -> InteractionState:
        if self._state in {InteractionState.IDLE, InteractionState.RECOVERY}:
            self._transition(InteractionState.NOTICED_HUMAN, target_id=target_id, reason=reason)
        if self._state in {InteractionState.NOTICED_HUMAN, InteractionState.MUTUAL_ATTENTION}:
            self._transition(InteractionState.MUTUAL_ATTENTION, target_id=target_id, reason=reason)
        return self._state

    def on_engagement_bid(
        self,
        *,
        target_id: str | None = None,
        reason: str = "engagement_bid",
    ) -> InteractionState:
        if self._state in {InteractionState.IDLE, InteractionState.RECOVERY}:
            self._transition(InteractionState.NOTICED_HUMAN, target_id=target_id, reason=reason)
        if self._state in {
            InteractionState.NOTICED_HUMAN,
            InteractionState.MUTUAL_ATTENTION,
            InteractionState.ENGAGING,
        }:
            self._transition(InteractionState.ENGAGING, target_id=target_id, reason=reason)
        return self._state

    def on_interaction_started(
        self,
        *,
        target_id: str | None = None,
        reason: str = "interaction_started",
    ) -> InteractionState:
        if self._state == InteractionState.SAFETY_OVERRIDE:
            return self._state
        if self._state in {
            InteractionState.IDLE,
            InteractionState.RECOVERY,
            InteractionState.NOTICED_HUMAN,
            InteractionState.MUTUAL_ATTENTION,
            InteractionState.ENGAGING,
            InteractionState.ONGOING_INTERACTION,
        }:
            self._transition(InteractionState.ONGOING_INTERACTION, target_id=target_id, reason=reason)
        return self._state

    def on_interaction_finished(self, *, reason: str = "interaction_finished") -> InteractionState:
        if self._state == InteractionState.ONGOING_INTERACTION:
            self._transition(InteractionState.RECOVERY, target_id=self._current_target_id, reason=reason)
        return self._state

    def on_attention_lost(
        self,
        *,
        target_id: str | None = None,
        reason: str = "attention_lost",
    ) -> InteractionState:
        if self._state == InteractionState.ONGOING_INTERACTION:
            self._transition(InteractionState.RECOVERY, target_id=target_id or self._current_target_id, reason=reason)
        elif self._state in {InteractionState.ENGAGING, InteractionState.MUTUAL_ATTENTION, InteractionState.NOTICED_HUMAN}:
            self._transition(InteractionState.RECOVERY, target_id=target_id or self._current_target_id, reason=reason)
        return self._state

    def on_weak_signal(self, *, target_id: str | None = None, reason: str = "weak_signal") -> InteractionState:
        """Backward-compatible wrapper for tentative detection."""
        return self.on_notice_human(target_id=target_id, reason=reason)

    def on_confirmed_engagement(
        self,
        *,
        target_id: str | None = None,
        reason: str = "confirmed_engagement",
    ) -> InteractionState:
        """Backward-compatible wrapper for stronger intent."""
        return self.on_engagement_bid(target_id=target_id, reason=reason)

    def on_disengage(self, *, target_id: str | None = None, reason: str = "disengage") -> InteractionState:
        """Backward-compatible wrapper for interaction exit."""
        return self.on_attention_lost(target_id=target_id, reason=reason)

    def on_safety_event(self, *, reason: str = "safety_event") -> InteractionState:
        """P0 safety event — override from any state."""
        if self._state != InteractionState.SAFETY_OVERRIDE:
            self._previous_state = self._state
            self._transition(InteractionState.SAFETY_OVERRIDE, target_id=self._current_target_id, reason=reason)
        return self._state

    def on_safety_resolved(self, *, reason: str = "safety_resolved") -> InteractionState:
        """Safety condition cleared."""
        if self._state == InteractionState.SAFETY_OVERRIDE:
            self._transition(InteractionState.RECOVERY, target_id=self._current_target_id, reason=reason)
        return self._state

    def tick(self) -> InteractionState:
        """Called each cycle. Handles timeout-based transitions."""
        elapsed = self.time_in_state_s
        if self._state == InteractionState.NOTICED_HUMAN and elapsed > self.TIMEOUT_NOTICED_S:
            self._transition(InteractionState.IDLE, target_id=self._current_target_id, reason="noticed_timeout")
        elif self._state == InteractionState.MUTUAL_ATTENTION and elapsed > self.TIMEOUT_MUTUAL_ATTENTION_S:
            self._transition(InteractionState.RECOVERY, target_id=self._current_target_id, reason="mutual_attention_timeout")
        elif self._state == InteractionState.ENGAGING and elapsed > self.TIMEOUT_ENGAGING_S:
            self._transition(InteractionState.RECOVERY, target_id=self._current_target_id, reason="engaging_timeout")
        elif self._state == InteractionState.ONGOING_INTERACTION and elapsed > self.TIMEOUT_ONGOING_S:
            self._transition(InteractionState.RECOVERY, target_id=self._current_target_id, reason="interaction_timeout")
        elif self._state == InteractionState.RECOVERY and elapsed > self.TIMEOUT_RECOVERY_S:
            self._transition(InteractionState.IDLE, target_id=None, reason="recovery_timeout")
        elif self._state == InteractionState.SAFETY_OVERRIDE and elapsed > self.TIMEOUT_SAFETY_S:
            self._transition(InteractionState.RECOVERY, target_id=self._current_target_id, reason="safety_timeout")
        return self._state

    def reset(self) -> None:
        self._state = InteractionState.IDLE
        self._entered_at = monotonic()
        self._transition_count = 0
        self._previous_state = None
        self._current_target_id = None
        self._last_reason = None

    def snapshot(self) -> dict[str, Any]:
        return {
            "state": self._state.name,
            "time_in_state_s": round(self.time_in_state_s, 2),
            "transition_count": self._transition_count,
            "previous_state": self._previous_state.name if self._previous_state else None,
            "target_id": self._current_target_id,
            "last_reason": self._last_reason,
        }

    # ── Internal ────────────────────────────────────────────────

    def _refresh(self, *, target_id: str | None, reason: str) -> None:
        if target_id:
            self._current_target_id = target_id
        self._entered_at = monotonic()
        self._last_reason = reason

    def _transition(
        self,
        new_state: InteractionState,
        *,
        target_id: str | None,
        reason: str,
    ) -> None:
        old = self._state
        if old == new_state:
            self._refresh(target_id=target_id, reason=reason)
            return
        self._previous_state = old
        self._state = new_state
        self._entered_at = monotonic()
        self._transition_count += 1
        self._current_target_id = target_id
        self._last_reason = reason
        logger.debug(
            "state_machine: %s → %s (transition #%d, target=%s, reason=%s)",
            old.name,
            new_state.name,
            self._transition_count,
            self._current_target_id,
            self._last_reason,
        )
