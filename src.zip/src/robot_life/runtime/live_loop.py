from __future__ import annotations

from dataclasses import replace
import logging
from queue import Empty as QueueEmpty, Full as QueueFull, Queue
from dataclasses import dataclass, field
from threading import Event, Thread
from time import monotonic, sleep
from typing import Any, Mapping

from robot_life.behavior.executor import BehaviorExecutor
from robot_life.behavior.decay_tracker import BehaviorDecayTracker
from robot_life.common.robot_context import RobotContextStore
from robot_life.common.state_machine import InteractionStateMachine
from robot_life.common.contracts import canonical_event_detected, priority_rank
from robot_life.common.schemas import DecisionMode, DetectionResult, EventPriority, SceneCandidate
from robot_life.event_engine.arbitrator import Arbitrator
from robot_life.event_engine.arbitration_runtime import ArbitrationBatchOutcome, ArbitrationRuntime
from robot_life.event_engine.builder import EventBuilder
from robot_life.event_engine.cooldown_manager import CooldownManager
from robot_life.event_engine.entity_tracker import EntityTracker
from robot_life.event_engine.scene_aggregator import SceneAggregator
from robot_life.event_engine.stabilizer import EventStabilizer
from robot_life.event_engine.temporal_event_layer import TemporalEventLayer
from robot_life.perception.frame_dispatch import build_camera_dispatch, frame_seq_of
from robot_life.runtime.sources import FramePacket, SourceBundle
from robot_life.runtime.telemetry import NullTelemetrySink, TelemetrySink, emit_stage_trace


logger = logging.getLogger(__name__)


@dataclass
class CollectedFrames:
    """Snapshot of the latest source samples."""

    packets: dict[str, FramePacket] = field(default_factory=dict)
    frames: dict[str, Any] = field(default_factory=dict)
    collected_at: float = field(default_factory=monotonic)
    frame_seq: int = 0


@dataclass
class LiveLoopDependencies:
    """Optional event-engine components wired into the live loop."""

    builder: EventBuilder | None = None
    stabilizer: EventStabilizer | None = None
    aggregator: SceneAggregator | None = None
    arbitrator: Arbitrator | None = None
    arbitration_runtime: ArbitrationRuntime | None = None
    executor: BehaviorExecutor | None = None
    cooldown_manager: CooldownManager | None = None
    decay_tracker: BehaviorDecayTracker | None = None
    interaction_state_machine: InteractionStateMachine | None = None
    robot_context_store: RobotContextStore | None = None
    entity_tracker: EntityTracker | None = None
    temporal_event_layer: TemporalEventLayer | None = None
    slow_scene: Any | None = None
    telemetry: TelemetrySink | None = None
    event_priorities: Mapping[str, EventPriority] | None = None


@dataclass
class LiveLoopResult:
    """Result bundle produced by one live-loop iteration."""

    collected_frames: CollectedFrames
    detections: list[DetectionResult] = field(default_factory=list)
    raw_events: list[Any] = field(default_factory=list)
    stable_events: list[Any] = field(default_factory=list)
    scene_candidates: list[Any] = field(default_factory=list)
    arbitration_results: list[Any] = field(default_factory=list)
    execution_results: list[Any] = field(default_factory=list)
    slow_scene_results: list[Any] = field(default_factory=list)
    pipeline_outputs: list[tuple[str, dict[str, Any]]] = field(default_factory=list)
    scene_batches: dict[str, list[Any]] = field(default_factory=dict)


@dataclass
class PendingDetection:
    sequence_id: int
    pipeline_name: str
    detection: DetectionResult
    priority: EventPriority


@dataclass
class _AsyncExecutionResult:
    decision: Any
    execution: Any
    resumed_decisions: list[Any]
    started_at: float
    ended_at: float


@dataclass
class _AsyncPerceptionResult:
    collected_frames: CollectedFrames
    pipeline_outputs: list[tuple[str, dict[str, Any]]]
    started_at: float
    ended_at: float


def collect_frames(source_bundle: SourceBundle) -> CollectedFrames:
    """Collect the latest packets and payloads from the configured sources."""
    collected_at = monotonic()
    packets = source_bundle.read_packets()
    frames = {source_name: packet.payload for source_name, packet in packets.items()}
    frame_seq = 0
    for packet in packets.values():
        try:
            frame_seq = max(frame_seq, int(getattr(packet, "frame_index", 0)))
        except (TypeError, ValueError):
            continue
    camera_packet = packets.get("camera")
    if camera_packet is not None:
        frames["camera"] = build_camera_dispatch(
            camera_packet.payload,
            frame_seq=int(getattr(camera_packet, "frame_index", frame_seq) or frame_seq),
            collected_at=collected_at,
        )
    return CollectedFrames(
        packets=packets,
        frames=frames,
        collected_at=collected_at,
        frame_seq=frame_seq,
    )


def infer_event_priority(detection: DetectionResult) -> EventPriority:
    """Best-effort priority inference until detector configs are fully wired in."""
    payload_priority = detection.payload.get("priority")
    if isinstance(payload_priority, EventPriority):
        return payload_priority
    if isinstance(payload_priority, str):
        try:
            return EventPriority[payload_priority]
        except KeyError:
            pass

    event_type = detection.event_type.lower()
    if any(token in event_type for token in ("collision", "emergency", "alarm", "safety", "loud_sound")):
        return EventPriority.P0
    if any(token in event_type for token in ("gesture", "touch", "wake")):
        return EventPriority.P1
    if any(token in event_type for token in ("face", "gaze", "attention")):
        return EventPriority.P2
    if "motion" in event_type:
        return EventPriority.P3
    return EventPriority.P2


def _canonical_priority_key(event_type: str) -> str:
    return canonical_event_detected(event_type)


def resolve_event_priority(
    detection: DetectionResult,
    configured_priorities: Mapping[str, EventPriority] | None = None,
) -> EventPriority:
    if configured_priorities:
        configured = configured_priorities.get(_canonical_priority_key(detection.event_type))
        if configured is not None:
            return configured
    return infer_event_priority(detection)


class LiveLoop:
    """Runnable live-runtime skeleton for camera and microphone sources."""

    def __init__(
        self,
        registry: Any,
        source_bundle: SourceBundle,
        dependencies: LiveLoopDependencies | None = None,
        *,
        telemetry: TelemetrySink | None = None,
        enable_slow_scene: bool = False,
        arbitration_batch_window_ms: int = 40,
        fast_path_budget_ms: float = 35.0,
        fast_path_pending_limit: int = 64,
        max_scenes_per_cycle: int = 4,
        max_queued_exec_per_cycle: int = 3,
        queue_drain_latency_budget_ms: float = 100.0,
        queue_drain_pending_threshold: int = 4,
        queue_drain_exec_time_budget_ms: float = 12.0,
        async_perception_enabled: bool = False,
        async_perception_queue_limit: int = 4,
        async_perception_result_max_age_ms: float = 140.0,
        async_perception_result_max_frame_lag: int = 3,
        async_executor_enabled: bool = False,
        async_executor_queue_limit: int = 64,
        async_capture_enabled: bool = False,
        async_capture_queue_limit: int = 2,
    ) -> None:
        self.registry = registry
        self.source_bundle = source_bundle
        self.dependencies = dependencies or LiveLoopDependencies()
        if self.dependencies.interaction_state_machine is None:
            self.dependencies.interaction_state_machine = InteractionStateMachine()
        if self.dependencies.robot_context_store is None:
            self.dependencies.robot_context_store = RobotContextStore()
        if self.dependencies.entity_tracker is None:
            self.dependencies.entity_tracker = EntityTracker()
        if self.dependencies.temporal_event_layer is None:
            self.dependencies.temporal_event_layer = TemporalEventLayer()
        self.telemetry = telemetry or self.dependencies.telemetry or NullTelemetrySink()
        self.enable_slow_scene = enable_slow_scene
        self.arbitration_batch_window_ms = max(1, int(arbitration_batch_window_ms))
        self.fast_path_budget_ms = max(1.0, float(fast_path_budget_ms))
        self.fast_path_pending_limit = max(1, int(fast_path_pending_limit))
        self.max_scenes_per_cycle = max(1, int(max_scenes_per_cycle))
        self.max_queued_exec_per_cycle = max(1, int(max_queued_exec_per_cycle))
        self.queue_drain_latency_budget_ms = max(10.0, float(queue_drain_latency_budget_ms))
        self.queue_drain_pending_threshold = max(1, int(queue_drain_pending_threshold))
        self.queue_drain_exec_time_budget_ms = max(1.0, float(queue_drain_exec_time_budget_ms))
        self.async_perception_enabled = bool(async_perception_enabled)
        self.async_perception_queue_limit = max(1, int(async_perception_queue_limit))
        self.async_perception_result_max_age_ms = max(0.0, float(async_perception_result_max_age_ms))
        self.async_perception_result_max_frame_lag = max(0, int(async_perception_result_max_frame_lag))
        self.async_executor_enabled = bool(async_executor_enabled)
        self.async_executor_queue_limit = max(1, int(async_executor_queue_limit))
        self.async_capture_enabled = bool(async_capture_enabled)
        self.async_capture_queue_limit = max(1, int(async_capture_queue_limit))
        self._running = False
        self._slow_scene_pending: dict[str, SceneCandidate] = {}
        self._last_slow_scene_submit_at = 0.0
        self._last_slow_scene_submit_at_by_target: dict[str, float] = {}
        self._last_cycle_latency_ms = 0.0
        self._queue_pressure_streak = 0
        self._load_shed_mode = "normal"
        self._load_shed_active = False
        self._load_shed_pipeline_scales: dict[str, float] = {}
        self._slow_scene_base_force_sample: bool | None = None
        self._slow_scene_base_sample_interval_s: float | None = None
        self._load_shed_targets: tuple[str, ...] = ("face", "gaze", "motion")
        self._load_shed_light_scale = 0.5
        self._load_shed_strong_scale = 0.33
        self._load_shed_light_interval_s = 8.0
        self._load_shed_strong_interval_s = 12.0
        self._pending_detections: list[PendingDetection] = []
        self._pending_detection_sequence = 0
        self._perception_thread: Thread | None = None
        self._perception_stop_event = Event()
        self._perception_inbox: Queue[CollectedFrames] | None = None
        self._perception_outbox: Queue[_AsyncPerceptionResult] | None = None
        self._async_perception_stale_dropped = 0
        self._async_perception_frame_lag_dropped = 0
        self._async_perception_last_result_age_ms = 0.0
        self._capture_thread: Thread | None = None
        self._capture_stop_event = Event()
        self._capture_outbox: Queue[CollectedFrames] | None = None
        self._executor_thread: Thread | None = None
        self._executor_stop_event = Event()
        self._executor_inbox: Queue[Any] | None = None
        self._executor_outbox: Queue[_AsyncExecutionResult] | None = None
        self._interaction_snapshot: dict[str, Any] = self.dependencies.interaction_state_machine.snapshot()
        self._decay_snapshot: dict[str, Any] = {}

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self) -> None:
        """Open sources and initialize all registered pipelines."""
        self.source_bundle.open_all()
        if hasattr(self.registry, "initialize_all"):
            self.registry.initialize_all()
        self._start_async_capture()
        self._start_async_perception()
        self._start_async_executor()
        self._running = True

    def stop(self) -> None:
        """Stop the loop and close all sources/pipelines."""
        self._running = False
        self._stop_async_perception()
        self._stop_async_capture()
        self._stop_async_executor()
        if hasattr(self.registry, "close_all"):
            self.registry.close_all()
        self.source_bundle.close_all()

    def run_once(self) -> LiveLoopResult:
        """Process one snapshot from all live sources."""
        cycle_started_at = monotonic()
        collected, pipeline_outputs, pipeline_started_at, pipeline_ended_at, pipeline_mode = self._collect_and_process_pipelines()
        result = LiveLoopResult(collected_frames=collected, pipeline_outputs=pipeline_outputs)
        emit_stage_trace(
            self.telemetry,
            trace_id=f"loop-{int(pipeline_started_at * 1000)}",
            stage="pipeline_registry",
            payload={
                "output_count": len(pipeline_outputs),
                "frame_sources": list(collected.frames.keys()),
                "mode": pipeline_mode,
            },
            started_at=pipeline_started_at,
            ended_at=pipeline_ended_at,
        )

        builder = self.dependencies.builder
        stabilizer = self.dependencies.stabilizer
        aggregator = self.dependencies.aggregator
        temporal_event_layer = self.dependencies.temporal_event_layer
        arbitrator = self.dependencies.arbitrator
        arbitration_runtime = self.dependencies.arbitration_runtime
        executor = self.dependencies.executor
        slow_scene = self.dependencies.slow_scene

        if self.enable_slow_scene and slow_scene is not None:
            ready_results = self._drain_ready_slow_scene_results(slow_scene)
            for _base_scene, scene_json in ready_results:
                result.slow_scene_results.append(scene_json)
                emit_stage_trace(
                    self.telemetry,
                    _base_scene.trace_id,
                    "slow_scene",
                    payload={"scene_type": scene_json.scene_type, "confidence": scene_json.confidence},
                    started_at=monotonic(),
                    ended_at=monotonic(),
                )
        self._drain_async_execution_results(
            result,
            arbitration_runtime=arbitration_runtime,
        )

        fast_path_started_at = monotonic()
        work_items = self._build_detection_work_items(collected, pipeline_outputs)
        processed_detection_count = 0
        deferred_due_to_budget = 0
        dropped_due_to_pending_limit = 0

        for index, work_item in enumerate(work_items):
            elapsed_fast_path_ms = (monotonic() - fast_path_started_at) * 1000.0
            if elapsed_fast_path_ms >= self.fast_path_budget_ms:
                deferred_due_to_budget = len(work_items) - index
                dropped_due_to_pending_limit = self._stash_pending_detections(work_items[index:])
                break

            detection = work_item.detection
            pipeline_name = work_item.pipeline_name
            priority = work_item.priority
            processed_detection_count += 1

            detection_started_at = monotonic()
            result.detections.append(detection)
            emit_stage_trace(
                self.telemetry,
                detection.trace_id,
                f"{pipeline_name}:detection",
                payload={"event_type": detection.event_type, "confidence": detection.confidence},
                started_at=detection_started_at,
                ended_at=monotonic(),
            )

            if builder is None or stabilizer is None:
                continue

            build_started_at = monotonic()
            raw_event = builder.build(
                detection,
                priority=priority,
            )
            result.raw_events.append(raw_event)
            emit_stage_trace(
                self.telemetry,
                raw_event.trace_id,
                "event_builder",
                payload={"event_type": raw_event.event_type, "priority": raw_event.priority.value},
                started_at=build_started_at,
                ended_at=monotonic(),
            )

            stabilizer_started_at = monotonic()
            stable_event = stabilizer.process(raw_event)
            if stable_event is None:
                emit_stage_trace(
                    self.telemetry,
                    raw_event.trace_id,
                    "event_stabilizer",
                    status="filtered",
                    payload={"event_type": raw_event.event_type},
                    started_at=stabilizer_started_at,
                    ended_at=monotonic(),
                )
                continue

            temporal_events = [stable_event]
            if temporal_event_layer is not None:
                temporal_events = temporal_event_layer.process(stable_event)

            for temporal_event in temporal_events:
                result.stable_events.append(temporal_event)
                stage_name = "temporal_event_layer" if temporal_event is not stable_event else "event_stabilizer"
                emit_stage_trace(
                    self.telemetry,
                    temporal_event.trace_id,
                    stage_name,
                    payload={"event_type": temporal_event.event_type, "stabilized_by": temporal_event.stabilized_by},
                    started_at=stabilizer_started_at,
                    ended_at=monotonic(),
                )

                if aggregator is None:
                    continue

                aggregate_started_at = monotonic()
                scene = aggregator.aggregate(temporal_event)
                if scene is None:
                    emit_stage_trace(
                        self.telemetry,
                        temporal_event.trace_id,
                        "scene_aggregator",
                        status="filtered_by_aggregator",
                        payload={"event_type": temporal_event.event_type},
                        started_at=aggregate_started_at,
                        ended_at=monotonic(),
                    )
                    continue
                result.scene_candidates.append(scene)
                emit_stage_trace(
                    self.telemetry,
                    scene.trace_id,
                    "scene_aggregator",
                    payload={"scene_type": scene.scene_type, "score_hint": scene.score_hint},
                    started_at=aggregate_started_at,
                    ended_at=monotonic(),
                )

        emit_stage_trace(
            self.telemetry,
            trace_id=f"loop-{int(cycle_started_at * 1000)}",
            stage="fast_path_budget",
            payload={
                "fast_path_budget_ms": round(self.fast_path_budget_ms, 3),
                "fast_path_processed_detections": processed_detection_count,
                "fast_path_deferred_detections": deferred_due_to_budget,
                "fast_path_pending_backlog": len(self._pending_detections),
                "fast_path_dropped_due_to_pending_limit": dropped_due_to_pending_limit,
            },
            started_at=fast_path_started_at,
            ended_at=monotonic(),
        )

        if result.scene_candidates and (arbitrator is not None or arbitration_runtime is not None):
            self._process_scene_batch(
                result,
                collected=collected,
                arbitrator=arbitrator,
                arbitration_runtime=arbitration_runtime,
                executor=executor,
                slow_scene=slow_scene,
            )

        queue_drain_stats = self._drain_queued_decisions(
            result,
            arbitration_runtime=arbitration_runtime,
            executor=executor,
        )
        self._tick_active_executor(
            result,
            arbitration_runtime=arbitration_runtime,
            executor=executor,
        )
        cycle_latency_ms = (monotonic() - cycle_started_at) * 1000.0
        self._update_queue_pressure_state(
            cycle_latency_ms,
            queue_pending=int(queue_drain_stats["queue_pending_after"]),
        )
        load_shed_stats = self._apply_load_shed_controls(
            queue_pending=int(queue_drain_stats["queue_pending_after"]),
            cycle_latency_ms=cycle_latency_ms,
            slow_scene=slow_scene,
        )
        queue_drain_stats.update(load_shed_stats)
        emit_stage_trace(
            self.telemetry,
            trace_id=f"loop-{int(cycle_started_at * 1000)}",
            stage="queue_drain",
            payload=queue_drain_stats,
            started_at=cycle_started_at,
            ended_at=monotonic(),
        )
        emit_stage_trace(
            self.telemetry,
            trace_id=f"loop-{int(cycle_started_at * 1000)}",
            stage="load_shed",
            payload=load_shed_stats,
            started_at=cycle_started_at,
            ended_at=monotonic(),
        )
        self._update_life_state(result)
        self._update_robot_context(result)

        return result

    def _collect_and_process_pipelines(
        self,
    ) -> tuple[CollectedFrames, list[tuple[str, dict[str, Any]]], float, float, str]:
        collected, capture_mode = self._collect_frames_for_cycle()
        if not collected.frames and capture_mode != "capture_sync":
            now = monotonic()
            return collected, [], now, now, f"{capture_mode}:no_frame"
        if not self.async_perception_enabled or self._perception_inbox is None or self._perception_outbox is None:
            started_at = monotonic()
            pipeline_outputs = self.registry.process_all(collected.frames)
            ended_at = monotonic()
            return collected, pipeline_outputs, started_at, ended_at, f"{capture_mode}:sync"

        self._submit_async_perception(collected)
        latest = self._drain_async_perception_results()
        if latest is None:
            now = monotonic()
            return collected, [], now, now, f"{capture_mode}:async_pending"
        result_age_ms = max(0.0, (monotonic() - latest.collected_frames.collected_at) * 1000.0)
        self._async_perception_last_result_age_ms = result_age_ms
        if (
            self.async_perception_result_max_age_ms > 0.0
            and result_age_ms > self.async_perception_result_max_age_ms
        ):
            self._async_perception_stale_dropped += 1
            logger.warning(
                "drop stale async perception result age=%.2fms threshold=%.2fms dropped=%s",
                result_age_ms,
                self.async_perception_result_max_age_ms,
                self._async_perception_stale_dropped,
            )
            now = monotonic()
            return collected, [], now, now, f"{capture_mode}:async_stale_drop"
        if (
            self.async_perception_result_max_frame_lag > 0
            and not self.async_capture_enabled
            and collected.frame_seq > 0
            and latest.collected_frames.frame_seq > 0
        ):
            frame_lag = max(0, int(collected.frame_seq - latest.collected_frames.frame_seq))
            if frame_lag > self.async_perception_result_max_frame_lag:
                self._async_perception_frame_lag_dropped += 1
                logger.warning(
                    "drop async perception result due to frame lag=%s threshold=%s dropped=%s",
                    frame_lag,
                    self.async_perception_result_max_frame_lag,
                    self._async_perception_frame_lag_dropped,
                )
                now = monotonic()
                return collected, [], now, now, f"{capture_mode}:async_frame_lag_drop"
        return (
            latest.collected_frames,
            latest.pipeline_outputs,
            latest.started_at,
            latest.ended_at,
            f"{capture_mode}:async_ready",
        )

    def _collect_frames_for_cycle(self) -> tuple[CollectedFrames, str]:
        if not self.async_capture_enabled or self._capture_outbox is None:
            return collect_frames(self.source_bundle), "capture_sync"
        latest = self._drain_async_capture_results()
        if latest is not None:
            return latest, "capture_async_ready"
        return CollectedFrames(collected_at=monotonic()), "capture_async_pending"

    def _start_async_capture(self) -> None:
        if not self.async_capture_enabled:
            return
        if self._capture_thread is not None and self._capture_thread.is_alive():
            return
        self._capture_stop_event.clear()
        self._capture_outbox = Queue(maxsize=self.async_capture_queue_limit)
        self._capture_thread = Thread(
            target=self._async_capture_worker,
            name="source-capture-async",
            daemon=True,
        )
        self._capture_thread.start()

    def _stop_async_capture(self) -> None:
        self._capture_stop_event.set()
        thread = self._capture_thread
        self._capture_thread = None
        if thread is not None and thread.is_alive():
            thread.join(timeout=1.0)
        self._capture_outbox = None

    def _async_capture_worker(self) -> None:
        outbox = self._capture_outbox
        if outbox is None:
            return
        while not self._capture_stop_event.is_set():
            try:
                collected = collect_frames(self.source_bundle)
            except Exception as exc:  # pragma: no cover - runtime guard
                logger.exception("async capture worker failed: %s", exc)
                continue

            if not collected.frames:
                continue
            try:
                outbox.put_nowait(collected)
            except QueueFull:
                try:
                    outbox.get_nowait()
                except QueueEmpty:
                    pass
                try:
                    outbox.put_nowait(collected)
                except QueueFull:
                    logger.warning("async capture outbox full, dropping newest frame snapshot")

    def _drain_async_capture_results(self) -> CollectedFrames | None:
        outbox = self._capture_outbox
        if outbox is None:
            return None
        latest: CollectedFrames | None = None
        while True:
            try:
                latest = outbox.get_nowait()
                outbox.task_done()
            except QueueEmpty:
                break
        return latest

    def _start_async_perception(self) -> None:
        if not self.async_perception_enabled:
            return
        if self._perception_thread is not None and self._perception_thread.is_alive():
            return
        self._perception_stop_event.clear()
        self._perception_inbox = Queue(maxsize=self.async_perception_queue_limit)
        self._perception_outbox = Queue(maxsize=self.async_perception_queue_limit * 2)
        self._perception_thread = Thread(
            target=self._async_perception_worker,
            name="pipeline-registry-async",
            daemon=True,
        )
        self._perception_thread.start()

    def _stop_async_perception(self) -> None:
        self._perception_stop_event.set()
        thread = self._perception_thread
        self._perception_thread = None
        if thread is not None and thread.is_alive():
            thread.join(timeout=1.0)
        self._perception_inbox = None
        self._perception_outbox = None

    def _async_perception_worker(self) -> None:
        inbox = self._perception_inbox
        outbox = self._perception_outbox
        if inbox is None or outbox is None:
            return
        while not self._perception_stop_event.is_set():
            try:
                collected = inbox.get(timeout=0.1)
            except QueueEmpty:
                continue
            started_at = monotonic()
            try:
                pipeline_outputs = self.registry.process_all(collected.frames)
            except Exception as exc:  # pragma: no cover - runtime guard
                logger.exception("async perception worker failed: %s", exc)
                pipeline_outputs = []
            ended_at = monotonic()
            payload = _AsyncPerceptionResult(
                collected_frames=collected,
                pipeline_outputs=pipeline_outputs,
                started_at=started_at,
                ended_at=ended_at,
            )
            try:
                outbox.put_nowait(payload)
            except QueueFull:
                try:
                    outbox.get_nowait()
                except QueueEmpty:
                    pass
                try:
                    outbox.put_nowait(payload)
                except QueueFull:
                    logger.warning("async perception outbox full, dropping newest result")
            finally:
                inbox.task_done()

    def _submit_async_perception(self, collected: CollectedFrames) -> None:
        inbox = self._perception_inbox
        if inbox is None:
            return
        try:
            inbox.put_nowait(collected)
            return
        except QueueFull:
            pass
        try:
            _ = inbox.get_nowait()
            inbox.task_done()
        except QueueEmpty:
            return
        try:
            inbox.put_nowait(collected)
        except QueueFull:
            logger.warning("async perception inbox full, drop collected frame")

    def _drain_async_perception_results(self) -> _AsyncPerceptionResult | None:
        outbox = self._perception_outbox
        if outbox is None:
            return None
        latest: _AsyncPerceptionResult | None = None
        while True:
            try:
                latest = outbox.get_nowait()
                outbox.task_done()
            except QueueEmpty:
                break
        return latest

    def _build_detection_work_items(
        self,
        collected: CollectedFrames,
        pipeline_outputs: list[tuple[str, dict[str, Any]]],
    ) -> list[PendingDetection]:
        work_items = list(self._pending_detections)
        self._pending_detections = []
        camera_frame = collected.frames.get("camera")
        camera_shape = getattr(camera_frame, "shape", None)
        frame_shape: tuple[int, int] | None = None
        if isinstance(camera_shape, tuple) and len(camera_shape) >= 2:
            try:
                frame_shape = (int(camera_shape[0]), int(camera_shape[1]))
            except (TypeError, ValueError):
                frame_shape = None

        raw_items: list[tuple[str, DetectionResult]] = []
        for pipeline_name, payload in pipeline_outputs:
            detections = payload.get("detections", []) or []
            for detection in detections:
                if not isinstance(detection, DetectionResult):
                    continue
                payload = detection.payload if isinstance(detection.payload, dict) else {}
                payload.setdefault("frame_seq", collected.frame_seq)
                payload.setdefault("frame_collected_at", collected.collected_at)
                camera_frame = collected.frames.get("camera")
                camera_seq = frame_seq_of(camera_frame)
                if camera_seq is not None:
                    payload.setdefault("camera_frame_seq", camera_seq)
                if frame_shape is not None:
                    payload.setdefault("frame_height", frame_shape[0])
                    payload.setdefault("frame_width", frame_shape[1])
                detection.payload = payload
                raw_items.append((pipeline_name, detection))

        entity_tracker = self.dependencies.entity_tracker
        if entity_tracker is not None and raw_items:
            raw_items = entity_tracker.associate_batch(raw_items, frame_shape=frame_shape)

        for pipeline_name, detection in raw_items:
            work_items.append(
                PendingDetection(
                    sequence_id=self._next_pending_detection_sequence(),
                    pipeline_name=pipeline_name,
                    detection=detection,
                    priority=resolve_event_priority(
                        detection,
                        self.dependencies.event_priorities,
                    ),
                )
            )

        work_items.sort(key=lambda item: (priority_rank(item.priority), item.sequence_id))
        return work_items

    def _stash_pending_detections(self, work_items: list[PendingDetection]) -> int:
        if not work_items:
            self._pending_detections = []
            return 0

        kept = sorted(
            work_items,
            key=lambda item: (priority_rank(item.priority), item.sequence_id),
        )[: self.fast_path_pending_limit]
        kept.sort(key=lambda item: item.sequence_id)
        self._pending_detections = kept
        return max(0, len(work_items) - len(kept))

    def _next_pending_detection_sequence(self) -> int:
        sequence_id = self._pending_detection_sequence
        self._pending_detection_sequence += 1
        return sequence_id

    def run_forever(
        self,
        *,
        poll_interval_s: float = 1.0 / 30.0,
        stop_event: Event | None = None,
        max_iterations: int | None = None,
    ) -> list[LiveLoopResult]:
        """Run the loop until stopped or iteration budget is exhausted."""
        if not self._running:
            self.start()

        results: list[LiveLoopResult] = []
        iteration = 0

        try:
            while self._running:
                if stop_event is not None and stop_event.is_set():
                    break
                if max_iterations is not None and iteration >= max_iterations:
                    break

                started_at = monotonic()
                try:
                    results.append(self.run_once())
                except Exception as exc:  # pragma: no cover - runtime safety net
                    logger.exception("live loop iteration failed: %s", exc)
                finally:
                    iteration += 1
                    elapsed = monotonic() - started_at
                    sleep(max(0.0, poll_interval_s - elapsed))
        finally:
            self.stop()

        return results

    def _submit_or_query_slow_scene(
        self,
        slow_scene: Any,
        scene: Any,
        collected: CollectedFrames,
        *,
        decision_mode: Any | None = None,
        arbitration_outcome: str | None = None,
    ) -> Any | None:
        camera_packet = collected.packets.get("camera")
        if camera_packet is not None and hasattr(slow_scene, "capture_frame"):
            slow_scene.capture_frame(
                camera_packet.payload,
                source="camera",
                metadata={"frame_index": camera_packet.frame_index},
            )

        sample_interval_s = float(getattr(slow_scene, "sample_interval_s", 1.0))
        target_key = getattr(scene, "target_id", None) or getattr(scene, "scene_type", "__global__")
        last_submit_at = self._last_slow_scene_submit_at_by_target.get(target_key, 0.0)
        if sample_interval_s > 0 and (monotonic() - last_submit_at) < sample_interval_s:
            return None

        should_trigger = scene.score_hint < 0.8
        if hasattr(slow_scene, "should_trigger"):
            should_trigger = slow_scene.should_trigger(
                scene,
                decision_mode=decision_mode,
                arbitration_outcome=arbitration_outcome,
            )

        force_sample = bool(getattr(slow_scene, "force_sample", True))
        if not should_trigger and not force_sample:
            return None

        timeout_ms = int(getattr(slow_scene, "request_timeout_ms", 5_000))

        if hasattr(slow_scene, "submit"):
            request_id = slow_scene.submit(
                scene,
                image=camera_packet.payload if camera_packet is not None else None,
                timeout_ms=timeout_ms,
            )
            request_state = None
            if hasattr(slow_scene, "get_request_state"):
                request_state = slow_scene.get_request_state(request_id)
            if request_state in {None, "PENDING", "RUNNING"}:
                self._slow_scene_pending[request_id] = scene
            submitted_at = monotonic()
            self._last_slow_scene_submit_at = submitted_at
            self._last_slow_scene_submit_at_by_target[target_key] = submitted_at
            return None

        if hasattr(slow_scene, "submit_scene"):
            request_id = slow_scene.submit_scene(
                scene,
                image=camera_packet.payload if camera_packet is not None else None,
                timeout_ms=timeout_ms,
            )
            if isinstance(request_id, str):
                request_state = None
                if hasattr(slow_scene, "get_request_state"):
                    request_state = slow_scene.get_request_state(request_id)
                if request_state in {None, "PENDING", "RUNNING"}:
                    self._slow_scene_pending[request_id] = scene
                submitted_at = monotonic()
                self._last_slow_scene_submit_at = submitted_at
                self._last_slow_scene_submit_at_by_target[target_key] = submitted_at
                return None

        if hasattr(slow_scene, "build_scene_json"):
            submitted_at = monotonic()
            self._last_slow_scene_submit_at = submitted_at
            self._last_slow_scene_submit_at_by_target[target_key] = submitted_at
            return slow_scene.build_scene_json(scene, image=camera_packet.payload if camera_packet is not None else None)

        return None

    def _drain_ready_slow_scene_results(self, slow_scene: Any) -> list[tuple[SceneCandidate, Any]]:
        if not hasattr(slow_scene, "query"):
            return []

        ready: list[tuple[SceneCandidate, Any]] = []
        for request_id, scene in list(self._slow_scene_pending.items()):
            slow_result = slow_scene.query(request_id=request_id)
            if slow_result is None:
                if hasattr(slow_scene, "get_request_state"):
                    state = slow_scene.get_request_state(request_id)
                    if state not in {None, "PENDING", "RUNNING"}:
                        self._slow_scene_pending.pop(request_id, None)
                continue

            status = getattr(slow_result, "status", None)
            status_value = status.value if hasattr(status, "value") else str(status)
            if status_value in {"PENDING", "RUNNING"}:
                continue

            self._slow_scene_pending.pop(request_id, None)
            ready.append((scene, slow_result.scene_json))
        return ready

    def _process_scene_batch(
        self,
        result: LiveLoopResult,
        *,
        collected: CollectedFrames,
        arbitrator: Arbitrator | None,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor | None,
        slow_scene: Any | None,
    ) -> None:
        scenes = self._coalesce_scene_candidates(
            result.scene_candidates,
            arbitrator=arbitrator,
            arbitration_runtime=arbitration_runtime,
        )

        # Three-layer cooldown filter (global + scene cooldown).
        cooldown_mgr = self.dependencies.cooldown_manager
        if cooldown_mgr is not None:
            state_machine = self.dependencies.interaction_state_machine
            robot_context_store = self.dependencies.robot_context_store
            active_target_id = state_machine.current_target_id if state_machine is not None else None
            active_execution = executor.get_current_execution() if executor is not None else None
            active_behavior_id = getattr(active_execution, "behavior_id", None)
            robot_busy = bool(active_execution is not None and getattr(active_execution, "status", None) == "running")
            robot_context = robot_context_store.snapshot() if robot_context_store is not None else {}
            filtered_scenes: list[SceneCandidate] = []
            for scene in scenes:
                if isinstance(scene.payload, dict):
                    scene.payload.setdefault("robot_mode", robot_context.get("mode"))
                    scene.payload.setdefault("robot_do_not_disturb", robot_context.get("do_not_disturb"))
                    scene.payload.setdefault("robot_busy", robot_busy)
                    scene.payload.setdefault("robot_active_behavior_id", active_behavior_id)
                    scene.payload.setdefault("robot_current_target_id", active_target_id)
                priority = self._scene_priority(scene, arbitrator or (arbitration_runtime.arbitrator if arbitration_runtime else None))
                allowed, reason = cooldown_mgr.check(
                    scene.scene_type,
                    scene.target_id,
                    priority,
                    active_target_id=active_target_id,
                    active_behavior_id=active_behavior_id,
                    robot_busy=robot_busy,
                )
                if allowed:
                    filtered_scenes.append(scene)
                else:
                    emit_stage_trace(
                        self.telemetry,
                        scene.trace_id,
                        "cooldown_filter",
                        status="suppressed",
                        payload={"scene_type": scene.scene_type, "reason": reason},
                        started_at=monotonic(),
                        ended_at=monotonic(),
                    )
            scenes = filtered_scenes

        partitioned = self._partition_scene_candidates_by_path(scenes)
        ordered_scene_candidates = partitioned["safety"] + partitioned["social"]
        result.scene_candidates = ordered_scene_candidates
        result.scene_batches = {
            "safety": list(partitioned["safety"]),
            "social": list(partitioned["social"]),
        }

        executed_safety = False
        for path_name in ("safety", "social"):
            path_scenes = partitioned[path_name]
            if not path_scenes:
                continue
            if path_name == "social" and executed_safety:
                for scene in path_scenes:
                    emit_stage_trace(
                        self.telemetry,
                        scene.trace_id,
                        "scene_route",
                        status="suppressed_by_safety",
                        payload={"scene_type": scene.scene_type, "scene_path": path_name},
                        started_at=monotonic(),
                        ended_at=monotonic(),
                    )
                continue

            for scene in path_scenes:
                emit_stage_trace(
                    self.telemetry,
                    scene.trace_id,
                    "scene_route",
                    payload={"scene_type": scene.scene_type, "scene_path": path_name},
                    started_at=monotonic(),
                    ended_at=monotonic(),
                )

            if arbitration_runtime is not None:
                outcomes = arbitration_runtime.submit_batch(
                    path_scenes,
                    batch_window_ms=self.arbitration_batch_window_ms,
                )
            else:
                outcomes = self._submit_batch_without_runtime(path_scenes, arbitrator)

            for outcome in outcomes:
                executed = self._record_batch_outcome(
                    result,
                    outcome=outcome,
                    collected=collected,
                    arbitration_runtime=arbitration_runtime,
                    executor=executor,
                    slow_scene=slow_scene,
                )
                if path_name == "safety" and executed:
                    executed_safety = True

    def _coalesce_scene_candidates(
        self,
        scenes: list[SceneCandidate],
        *,
        arbitrator: Arbitrator | None,
        arbitration_runtime: ArbitrationRuntime | None,
    ) -> list[SceneCandidate]:
        if not scenes:
            return []

        resolved_arbitrator = arbitrator
        if resolved_arbitrator is None and arbitration_runtime is not None:
            resolved_arbitrator = arbitration_runtime.arbitrator

        coalesced: dict[tuple[str, str | None], SceneCandidate] = {}
        for scene in scenes:
            key = (scene.scene_type, scene.target_id)
            existing = coalesced.get(key)
            if existing is None:
                coalesced[key] = scene
                continue

            better = scene if scene.score_hint >= existing.score_hint else existing
            merged_based_on_events = list(dict.fromkeys(existing.based_on_events + scene.based_on_events))
            merged_payload = dict(existing.payload)
            merged_payload.update(scene.payload)
            better.payload = merged_payload
            better.based_on_events = merged_based_on_events
            better.valid_until_monotonic = max(existing.valid_until_monotonic, scene.valid_until_monotonic)
            coalesced[key] = better

        ordered = sorted(
            coalesced.values(),
            key=lambda scene: (
                priority_rank(self._scene_priority(scene, resolved_arbitrator)),
                -float(scene.score_hint),
            ),
        )
        filtered: list[SceneCandidate] = []
        for scene in ordered:
            payload = scene.payload if isinstance(scene.payload, dict) else {}
            scene_path = str(payload.get("scene_path", "")).strip().lower()
            dominated = False
            for existing in filtered:
                if existing.target_id != scene.target_id:
                    continue
                existing_payload = existing.payload if isinstance(existing.payload, dict) else {}
                existing_path = str(existing_payload.get("scene_path", "")).strip().lower()
                if scene_path and existing_path and scene_path != existing_path:
                    continue
                if set(scene.based_on_events).issubset(set(existing.based_on_events)):
                    dominated = True
                    break
            if not dominated:
                filtered.append(scene)

        return filtered[: self.max_scenes_per_cycle]

    @staticmethod
    def _partition_scene_candidates_by_path(
        scenes: list[SceneCandidate],
    ) -> dict[str, list[SceneCandidate]]:
        batches: dict[str, list[SceneCandidate]] = {"safety": [], "social": []}
        for scene in scenes:
            payload = scene.payload if isinstance(scene.payload, dict) else {}
            raw_path = str(payload.get("scene_path", "")).strip().lower()
            if raw_path == "safety" or scene.scene_type == "safety_alert_scene":
                batches["safety"].append(scene)
            else:
                batches["social"].append(scene)
        return batches

    @staticmethod
    def _scene_priority(scene: SceneCandidate, arbitrator: Arbitrator | None) -> EventPriority:
        if arbitrator is None:
            return EventPriority.P2
        return arbitrator.decide(scene, current_priority=None).priority

    def _drain_queued_decisions(
        self,
        result: LiveLoopResult,
        *,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor | None,
    ) -> dict[str, Any]:
        if arbitration_runtime is None:
            return {
                "queue_drain_budget": 0,
                "queue_drain_executed": 0,
                "queue_drain_deferred": 0,
                "queue_pending_before": 0,
                "queue_pending_after": 0,
                "queue_pressure_streak": self._queue_pressure_streak,
                "last_cycle_latency_ms": round(self._last_cycle_latency_ms, 3),
            }

        pending_before = arbitration_runtime.pending()
        if executor is None:
            return {
                "queue_drain_budget": 0,
                "queue_drain_executed": 0,
                "queue_drain_deferred": pending_before,
                "queue_pending_before": pending_before,
                "queue_pending_after": pending_before,
                "queue_pressure_streak": self._queue_pressure_streak,
                "last_cycle_latency_ms": round(self._last_cycle_latency_ms, 3),
            }

        budget = self._resolve_queue_drain_budget(pending_before)
        executed = 0
        queue_drain_started_at = monotonic()
        hit_exec_time_budget = False

        while executed < budget:
            elapsed_ms = (monotonic() - queue_drain_started_at) * 1000.0
            if elapsed_ms >= self.queue_drain_exec_time_budget_ms:
                hit_exec_time_budget = True
                break
            queued = arbitration_runtime.complete_active()
            if queued is None:
                break
            self._record_executed_decision(
                result,
                queued,
                scene=None,
                arbitration_runtime=arbitration_runtime,
                executor=executor,
            )
            executed += 1

        pending_after = arbitration_runtime.pending()
        deferred = pending_after
        return {
            "queue_drain_budget": budget,
            "queue_drain_executed": executed,
            "queue_drain_deferred": deferred,
            "queue_pending_before": pending_before,
            "queue_pending_after": pending_after,
            "queue_pressure_streak": self._queue_pressure_streak,
            "last_cycle_latency_ms": round(self._last_cycle_latency_ms, 3),
            "queue_drain_duration_ms": round((monotonic() - queue_drain_started_at) * 1000.0, 3),
            "queue_drain_exec_time_budget_ms": round(self.queue_drain_exec_time_budget_ms, 3),
            "queue_drain_hit_exec_time_budget": hit_exec_time_budget,
        }

    def _resolve_queue_drain_budget(self, queue_pending: int) -> int:
        if queue_pending <= 0:
            return 0

        budget = self.max_queued_exec_per_cycle
        if self._queue_pressure_streak >= 2 or queue_pending >= self.queue_drain_pending_threshold * 2:
            budget -= 2
        elif self._queue_pressure_streak >= 1 or queue_pending >= self.queue_drain_pending_threshold:
            budget -= 1
        return max(1, min(self.max_queued_exec_per_cycle, budget))

    def _update_queue_pressure_state(self, cycle_latency_ms: float, *, queue_pending: int) -> None:
        self._last_cycle_latency_ms = float(cycle_latency_ms)
        pressure = (
            cycle_latency_ms > self.queue_drain_latency_budget_ms
            or queue_pending >= self.queue_drain_pending_threshold
        )
        if pressure:
            self._queue_pressure_streak += 1
        else:
            self._queue_pressure_streak = 0

    def _apply_load_shed_controls(
        self,
        *,
        queue_pending: int,
        cycle_latency_ms: float,
        slow_scene: Any | None,
    ) -> dict[str, Any]:
        mode, reasons = self._resolve_load_shed_mode(
            queue_pending=queue_pending,
            cycle_latency_ms=cycle_latency_ms,
        )
        load_shed_active = mode != "normal"
        self._load_shed_mode = mode
        self._load_shed_active = load_shed_active

        pipeline_scales = self._load_shed_pipeline_scales_for_mode(mode)
        self._load_shed_pipeline_scales = dict(pipeline_scales)
        self._apply_pipeline_runtime_scales(pipeline_scales)
        slow_scene_controls = self._apply_slow_scene_load_shed(slow_scene, mode)

        payload = {
            "load_shed_mode": mode,
            "load_shed_active": load_shed_active,
            "load_shed_reasons": reasons,
            "load_shed_queue_pending": queue_pending,
            "load_shed_cycle_latency_ms": round(float(cycle_latency_ms), 3),
            "load_shed_pipeline_scales": dict(pipeline_scales),
        }
        payload.update(slow_scene_controls)
        return payload

    def _resolve_load_shed_mode(
        self,
        *,
        queue_pending: int,
        cycle_latency_ms: float,
    ) -> tuple[str, list[str]]:
        reasons: list[str] = []
        latency_pressure = cycle_latency_ms > self.queue_drain_latency_budget_ms
        queue_pressure = queue_pending >= self.queue_drain_pending_threshold
        streak_pressure = self._queue_pressure_streak >= 1

        if latency_pressure:
            reasons.append("latency")
        if queue_pressure:
            reasons.append("queue_depth")
        if streak_pressure:
            reasons.append("streak")

        if (
            self._queue_pressure_streak >= 2
            or queue_pending >= self.queue_drain_pending_threshold * 2
            or cycle_latency_ms >= self.queue_drain_latency_budget_ms * 1.5
        ):
            return "strong", reasons or ["pressure"]
        if latency_pressure or queue_pressure or streak_pressure:
            return "light", reasons or ["pressure"]
        return "normal", []

    def _load_shed_pipeline_scales_for_mode(self, mode: str) -> dict[str, float]:
        if mode == "strong":
            scale = self._load_shed_strong_scale
        elif mode == "light":
            scale = self._load_shed_light_scale
        else:
            scale = 1.0
        return {pipeline_name: scale for pipeline_name in self._load_shed_targets}

    def _apply_pipeline_runtime_scales(self, scales: dict[str, float]) -> None:
        if hasattr(self.registry, "set_runtime_scales"):
            self.registry.set_runtime_scales(scales)
            return
        if hasattr(self.registry, "set_runtime_scale"):
            for pipeline_name, scale in scales.items():
                self.registry.set_runtime_scale(pipeline_name, scale)

    def _apply_slow_scene_load_shed(self, slow_scene: Any | None, mode: str) -> dict[str, Any]:
        if slow_scene is None:
            return {
                "slow_scene_force_sample": None,
                "slow_scene_sample_interval_s": None,
            }

        if self._slow_scene_base_force_sample is None and hasattr(slow_scene, "force_sample"):
            self._slow_scene_base_force_sample = bool(getattr(slow_scene, "force_sample", False))
        if self._slow_scene_base_sample_interval_s is None and hasattr(slow_scene, "sample_interval_s"):
            self._slow_scene_base_sample_interval_s = float(getattr(slow_scene, "sample_interval_s", 0.0))

        base_force_sample = self._slow_scene_base_force_sample
        base_interval_s = self._slow_scene_base_sample_interval_s

        if mode == "normal":
            if base_force_sample is not None and hasattr(slow_scene, "force_sample"):
                slow_scene.force_sample = base_force_sample
            if base_interval_s is not None and hasattr(slow_scene, "sample_interval_s"):
                slow_scene.sample_interval_s = base_interval_s
        else:
            if hasattr(slow_scene, "force_sample"):
                slow_scene.force_sample = False
            if hasattr(slow_scene, "sample_interval_s"):
                conservative_interval_s = self._load_shed_light_interval_s
                if mode == "strong":
                    conservative_interval_s = self._load_shed_strong_interval_s
                if base_interval_s is not None:
                    conservative_interval_s = max(base_interval_s * (2.0 if mode == "strong" else 1.5), conservative_interval_s)
                slow_scene.sample_interval_s = conservative_interval_s

        return {
            "slow_scene_force_sample": getattr(slow_scene, "force_sample", None),
            "slow_scene_sample_interval_s": getattr(slow_scene, "sample_interval_s", None),
        }

    def _submit_batch_without_runtime(
        self,
        scenes: list[SceneCandidate],
        arbitrator: Arbitrator | None,
    ) -> list[ArbitrationBatchOutcome]:
        if arbitrator is None:
            return []

        current_priority: EventPriority | None = None
        ordered_scenes = sorted(
            enumerate(scenes),
            key=lambda item: (priority_rank(arbitrator.decide(item[1], current_priority=None).priority), item[0]),
        )

        outcomes: list[ArbitrationBatchOutcome] = []
        for _index, scene in ordered_scenes:
            decision = arbitrator.decide(scene, current_priority=current_priority)
            executed = decision.mode != DecisionMode.DROP
            outcomes.append(
                ArbitrationBatchOutcome(
                    scene=scene,
                    decision=decision,
                    outcome="executed" if executed else "dropped",
                    executed=executed,
                )
            )
            if executed:
                current_priority = decision.priority
        return outcomes

    def _record_batch_outcome(
        self,
        result: LiveLoopResult,
        *,
        outcome: ArbitrationBatchOutcome,
        collected: CollectedFrames,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor | None,
        slow_scene: Any | None,
    ) -> bool:
        arbitration_started_at = monotonic()
        if not outcome.executed:
            self._emit_arbitration_trace(
                outcome.decision,
                status=outcome.outcome,
                queue_pending=arbitration_runtime.pending() if arbitration_runtime is not None else 0,
                started_at=arbitration_started_at,
            )
            self._maybe_emit_slow_scene(
                result,
                slow_scene=slow_scene,
                scene=outcome.scene,
                collected=collected,
                decision_mode=outcome.decision.mode,
                arbitration_outcome=outcome.outcome,
            )
            return False

        self._record_executed_decision(
            result,
            outcome.decision,
            scene=outcome.scene,
            arbitration_runtime=arbitration_runtime,
            executor=executor,
            started_at=arbitration_started_at,
        )
        self._maybe_emit_slow_scene(
            result,
            slow_scene=slow_scene,
            scene=outcome.scene,
            collected=collected,
            decision_mode=outcome.decision.mode,
            arbitration_outcome=outcome.outcome,
        )
        return True

    def _record_executed_decision(
        self,
        result: LiveLoopResult,
        decision: Any,
        *,
        scene: SceneCandidate | None,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor | None,
        started_at: float | None = None,
    ) -> None:
        decision = self._apply_behavior_decay_policy(decision, scene=scene)
        arbitration_started_at = started_at if started_at is not None else monotonic()
        result.arbitration_results.append(decision)
        self._emit_arbitration_trace(
            decision,
            status="ok",
            queue_pending=arbitration_runtime.pending() if arbitration_runtime is not None else 0,
            started_at=arbitration_started_at,
        )

        if executor is None:
            return

        if (
            self.async_executor_enabled
            and self._executor_inbox is not None
            and self._executor_outbox is not None
            and not bool(getattr(executor, "tick_execution_enabled", False))
        ):
            try:
                self._executor_inbox.put_nowait(decision)
            except QueueFull:
                logger.warning("async executor queue full, fallback to inline execution")
                self._execute_decision_inline(
                    result,
                    decision,
                    arbitration_runtime=arbitration_runtime,
                    executor=executor,
                )
            else:
                emit_stage_trace(
                    self.telemetry,
                    decision.trace_id,
                    "behavior_executor_async",
                    status="queued",
                    payload={
                        "target_behavior": decision.target_behavior,
                        "priority": decision.priority.value,
                    },
                    started_at=monotonic(),
                    ended_at=monotonic(),
                )
            return

        self._execute_decision_inline(
            result,
            decision,
            arbitration_runtime=arbitration_runtime,
            executor=executor,
        )

    def _execute_decision_inline(
        self,
        result: LiveLoopResult,
        decision: Any,
        *,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor,
    ) -> None:
        executor_started_at = monotonic()
        execution = executor.execute(decision)
        if execution.status == "running":
            emit_stage_trace(
                self.telemetry,
                decision.trace_id,
                "behavior_executor",
                status="running",
                payload={
                    "behavior_id": decision.target_behavior,
                    "status": execution.status,
                    "degraded": execution.degraded,
                    "interrupted": execution.interrupted,
                },
                started_at=executor_started_at,
                ended_at=monotonic(),
            )
            return

        result.execution_results.append(execution)
        self._record_decay_execution(execution)

        # Record execution for three-layer cooldown tracking.
        cooldown_mgr = self.dependencies.cooldown_manager
        if cooldown_mgr is not None and execution.status in {"finished", "degraded"}:
            scene_type = execution.scene_type or self._behavior_to_scene_type(execution.behavior_id)
            cooldown_mgr.record_execution(scene_type, target_id=execution.target_id)

        emit_stage_trace(
            self.telemetry,
            execution.trace_id,
            "behavior_executor",
            payload={
                "behavior_id": execution.behavior_id,
                "status": execution.status,
                "degraded": execution.degraded,
                "interrupted": execution.interrupted,
            },
            started_at=executor_started_at,
            ended_at=monotonic(),
        )
        self._handle_executor_resume(
            result,
            arbitration_runtime=arbitration_runtime,
            executor=executor,
        )

    def _tick_active_executor(
        self,
        result: LiveLoopResult,
        *,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor | None,
    ) -> None:
        if executor is None:
            return
        if self.async_executor_enabled:
            return
        tick_active = getattr(executor, "tick_active", None)
        if not callable(tick_active):
            return

        executor_started_at = monotonic()
        execution = tick_active()
        if execution is None:
            return
        result.execution_results.append(execution)
        self._record_decay_execution(execution)
        cooldown_mgr = self.dependencies.cooldown_manager
        if cooldown_mgr is not None and execution.status in {"finished", "degraded"}:
            scene_type = execution.scene_type or self._behavior_to_scene_type(execution.behavior_id)
            cooldown_mgr.record_execution(scene_type, target_id=execution.target_id)
        emit_stage_trace(
            self.telemetry,
            execution.trace_id,
            "behavior_executor",
            payload={
                "behavior_id": execution.behavior_id,
                "status": execution.status,
                "degraded": execution.degraded,
                "interrupted": execution.interrupted,
                "tick_mode": True,
            },
            started_at=executor_started_at,
            ended_at=monotonic(),
        )
        self._handle_executor_resume(
            result,
            arbitration_runtime=arbitration_runtime,
            executor=executor,
        )

    def _start_async_executor(self) -> None:
        if not self.async_executor_enabled:
            return
        executor = self.dependencies.executor
        if executor is None:
            return
        if bool(getattr(executor, "tick_execution_enabled", False)):
            logger.warning("async executor disabled because tick_execution is enabled")
            return
        if self._executor_thread is not None and self._executor_thread.is_alive():
            return
        self._executor_stop_event.clear()
        self._executor_inbox = Queue(maxsize=self.async_executor_queue_limit)
        self._executor_outbox = Queue(maxsize=self.async_executor_queue_limit * 2)
        self._executor_thread = Thread(
            target=self._async_executor_worker,
            args=(executor,),
            name="behavior-executor-async",
            daemon=True,
        )
        self._executor_thread.start()

    def _stop_async_executor(self) -> None:
        self._executor_stop_event.set()
        thread = self._executor_thread
        self._executor_thread = None
        if thread is not None and thread.is_alive():
            thread.join(timeout=1.0)
        self._executor_inbox = None
        self._executor_outbox = None

    def _async_executor_worker(self, executor: BehaviorExecutor) -> None:
        inbox = self._executor_inbox
        outbox = self._executor_outbox
        if inbox is None or outbox is None:
            return
        while not self._executor_stop_event.is_set():
            try:
                decision = inbox.get(timeout=0.1)
            except QueueEmpty:
                continue
            try:
                started_at = monotonic()
                execution = executor.execute(decision)
                ended_at = monotonic()
                resumed_decisions: list[Any] = []
                pop_resume = getattr(executor, "pop_resume_decision", None)
                if callable(pop_resume):
                    while True:
                        resumed = pop_resume()
                        if resumed is None:
                            break
                        resumed_decisions.append(resumed)
                try:
                    outbox.put_nowait(
                        _AsyncExecutionResult(
                            decision=decision,
                            execution=execution,
                            resumed_decisions=resumed_decisions,
                            started_at=started_at,
                            ended_at=ended_at,
                        )
                    )
                except QueueFull:
                    logger.warning("async executor outbox full, dropping execution result")
            except Exception as exc:  # pragma: no cover - runtime guard
                logger.exception("async executor worker failed: %s", exc)
            finally:
                inbox.task_done()

    def _drain_async_execution_results(
        self,
        result: LiveLoopResult,
        *,
        arbitration_runtime: ArbitrationRuntime | None,
    ) -> None:
        outbox = self._executor_outbox
        if not self.async_executor_enabled or outbox is None:
            return

        while True:
            try:
                item = outbox.get_nowait()
            except QueueEmpty:
                break

            result.execution_results.append(item.execution)
            self._record_decay_execution(item.execution)
            emit_stage_trace(
                self.telemetry,
                item.execution.trace_id,
                "behavior_executor",
                payload={
                    "behavior_id": item.execution.behavior_id,
                    "status": item.execution.status,
                    "degraded": item.execution.degraded,
                    "interrupted": item.execution.interrupted,
                    "async": True,
                },
                started_at=item.started_at,
                ended_at=item.ended_at,
            )
            for resumed in item.resumed_decisions:
                if arbitration_runtime is None:
                    continue
                enqueued = arbitration_runtime.queue.enqueue(
                    resumed,
                    timeout_ms=arbitration_runtime.arbitrator.queue_timeout_ms(resumed.priority),
                )
                emit_stage_trace(
                    self.telemetry,
                    resumed.trace_id,
                    "resume_enqueue",
                    status="queued" if enqueued is not None else "dropped",
                    payload={
                        "target_behavior": resumed.target_behavior,
                        "priority": resumed.priority.value,
                        "reason": resumed.reason,
                    },
                    started_at=monotonic(),
                    ended_at=monotonic(),
                )
            outbox.task_done()

    def _handle_executor_resume(
        self,
        result: LiveLoopResult,
        *,
        arbitration_runtime: ArbitrationRuntime | None,
        executor: BehaviorExecutor,
    ) -> None:
        pop_resume = getattr(executor, "pop_resume_decision", None)
        if not callable(pop_resume):
            return

        while True:
            resumed = pop_resume()
            if resumed is None:
                break

            if arbitration_runtime is not None:
                enqueued = arbitration_runtime.queue.enqueue(
                    resumed,
                    timeout_ms=arbitration_runtime.arbitrator.queue_timeout_ms(resumed.priority),
                )
                emit_stage_trace(
                    self.telemetry,
                    resumed.trace_id,
                    "resume_enqueue",
                    status="queued" if enqueued is not None else "dropped",
                    payload={
                        "target_behavior": resumed.target_behavior,
                        "priority": resumed.priority.value,
                        "reason": resumed.reason,
                    },
                    started_at=monotonic(),
                    ended_at=monotonic(),
                )
                continue

            self._record_executed_decision(
                result,
                resumed,
                scene=None,
                arbitration_runtime=None,
                executor=executor,
            )

    def _emit_arbitration_trace(
        self,
        decision: Any,
        *,
        status: str,
        queue_pending: int,
        started_at: float,
    ) -> None:
        emit_stage_trace(
            self.telemetry,
            decision.trace_id,
            "arbitrator",
            status=status,
            payload={
                "target_behavior": decision.target_behavior,
                "priority": decision.priority.value,
                "mode": decision.mode.value,
                "reason": decision.reason,
                "queue_pending": queue_pending,
            },
            started_at=started_at,
            ended_at=monotonic(),
        )

    def _apply_behavior_decay_policy(
        self,
        decision: Any,
        *,
        scene: SceneCandidate | None = None,
    ) -> Any:
        decay_tracker = self.dependencies.decay_tracker
        if decay_tracker is None:
            return decision

        scene_type = scene.scene_type if scene is not None else (decision.scene_type or self._behavior_to_scene_type(decision.target_behavior))
        target_id = getattr(scene, "target_id", None) if scene is not None else decision.target_id
        strength, use_voice = decay_tracker.evaluate(scene_type, target_id)
        degrade_applied = False
        adjusted_decision = decision
        if not use_voice and decision.degraded_behavior and decision.mode in {
            DecisionMode.EXECUTE,
            DecisionMode.SOFT_INTERRUPT,
            DecisionMode.DEGRADE_AND_EXECUTE,
        }:
            adjusted_decision = replace(
                decision,
                mode=DecisionMode.DEGRADE_AND_EXECUTE,
                reason=f"{decision.reason}|decay_silent:{strength:.2f}",
            )
            degrade_applied = True

        self._decay_snapshot = {
            "scene_type": scene_type,
            "target_id": target_id,
            "strength": round(float(strength), 3),
            "use_voice": bool(use_voice),
            "degrade_applied": degrade_applied,
        }
        return adjusted_decision

    def _record_decay_execution(self, execution: Any) -> None:
        decay_tracker = self.dependencies.decay_tracker
        if decay_tracker is None:
            return
        if execution.status not in {"finished", "degraded"}:
            return
        scene_type = execution.scene_type or self._behavior_to_scene_type(execution.behavior_id)
        decay_tracker.record(scene_type, execution.target_id)

    def _update_life_state(self, result: LiveLoopResult) -> None:
        state_machine = self.dependencies.interaction_state_machine
        if state_machine is None:
            return

        state_machine.tick()
        latest_scene = result.scene_candidates[-1] if result.scene_candidates else None
        latest_scene_payload = latest_scene.payload if latest_scene is not None and isinstance(latest_scene.payload, dict) else {}
        latest_interaction_state = str(latest_scene_payload.get("interaction_state", "")).strip().lower()
        latest_scene_path = str(latest_scene_payload.get("scene_path", "")).strip().lower()
        latest_target_id = getattr(latest_scene, "target_id", None) if latest_scene is not None else None
        latest_engagement_score = latest_scene_payload.get("engagement_score")
        stable_event_types = {event.event_type for event in result.stable_events}
        social_execution = next(
            (
                execution
                for execution in result.execution_results
                if execution.behavior_id in {
                    "perform_greeting",
                    "greeting_visual_only",
                    "perform_attention",
                    "attention_minimal",
                    "perform_gesture_response",
                    "gesture_visual_only",
                }
            ),
            None,
        )
        noticed_target_id = _latest_target_id_from_events(
            result.stable_events,
            preferred_event_types={"familiar_face_detected", "stranger_face_detected", "motion_detected"},
        ) or latest_target_id
        mutual_target_id = _latest_target_id_from_events(
            result.stable_events,
            preferred_event_types={"gaze_hold_start_detected", "gaze_sustained_detected"},
        ) or latest_target_id
        engagement_target_id = _latest_target_id_from_events(
            result.stable_events,
            preferred_event_types={"wave_detected", "gesture_detected"},
        ) or latest_target_id

        if any(event.priority == EventPriority.P0 for event in result.stable_events):
            state_machine.on_safety_event(reason="p0_stable_event")
        elif any(scene.scene_type == "safety_alert_scene" for scene in result.scene_candidates):
            state_machine.on_safety_event(reason="safety_scene")
        elif state_machine.current_state.name == "SAFETY_OVERRIDE":
            state_machine.on_safety_resolved(reason="safety_clear")
        elif "attention_lost_detected" in stable_event_types or "gaze_hold_end_detected" in stable_event_types:
            state_machine.on_attention_lost(target_id=mutual_target_id, reason="attention_lost")
        elif social_execution is not None:
            state_machine.on_interaction_started(
                target_id=social_execution.target_id or latest_target_id,
                reason=f"behavior_executed:{social_execution.behavior_id}",
            )
        elif any(scene.scene_type in {"greeting_scene", "gesture_bond_scene"} for scene in result.scene_candidates) or "wave_detected" in stable_event_types:
            state_machine.on_engagement_bid(target_id=engagement_target_id, reason="engagement_scene")
        elif latest_interaction_state in {"engaging", "mutual_attention"} or any(
            scene.scene_type in {"attention_scene", "stranger_attention_scene"}
            for scene in result.scene_candidates
        ) or {"gaze_hold_start_detected", "gaze_sustained_detected"} & stable_event_types:
            state_machine.on_mutual_attention(target_id=mutual_target_id, reason="mutual_attention_signal")
        elif any(
            scene.scene_type in {"ambient_tracking_scene", "attention_scene", "stranger_attention_scene"}
            for scene in result.scene_candidates
        ) or {"familiar_face_detected", "stranger_face_detected", "motion_detected"} & stable_event_types:
            state_machine.on_notice_human(target_id=noticed_target_id, reason="noticed_signal")

        self._interaction_snapshot = state_machine.snapshot()
        self._interaction_snapshot["latest_scene_type"] = getattr(latest_scene, "scene_type", None)
        self._interaction_snapshot["latest_target_id"] = latest_target_id
        self._interaction_snapshot["latest_scene_path"] = latest_scene_path or None
        self._interaction_snapshot["latest_interaction_state"] = latest_interaction_state or None
        self._interaction_snapshot["latest_engagement_score"] = (
            round(float(latest_engagement_score), 3)
            if latest_engagement_score is not None
            else None
        )
        emit_stage_trace(
            self.telemetry,
            trace_id=f"loop-life-{int(monotonic() * 1000)}",
            stage="interaction_state",
            payload={
                "interaction": dict(self._interaction_snapshot),
                "decay": dict(self._decay_snapshot),
            },
            started_at=monotonic(),
            ended_at=monotonic(),
        )

    def _update_robot_context(self, result: LiveLoopResult) -> None:
        robot_context_store = self.dependencies.robot_context_store
        executor = self.dependencies.executor
        if robot_context_store is None:
            return
        active_execution = executor.get_current_execution() if executor is not None else None
        robot_context_store.sync(
            interaction_snapshot=self._interaction_snapshot,
            active_execution=active_execution,
            execution_results=result.execution_results,
        )

    def snapshot_life_state(self) -> dict[str, Any]:
        tracker_snapshot: dict[str, Any] = {}
        entity_tracker = self.dependencies.entity_tracker
        if entity_tracker is not None:
            try:
                tracker_snapshot = entity_tracker.snapshot()
            except Exception:
                tracker_snapshot = {}
        temporal_snapshot: dict[str, Any] = {}
        temporal_event_layer = self.dependencies.temporal_event_layer
        if temporal_event_layer is not None:
            try:
                temporal_snapshot = temporal_event_layer.snapshot()
            except Exception:
                temporal_snapshot = {}
        robot_context_snapshot: dict[str, Any] = {}
        robot_context_store = self.dependencies.robot_context_store
        if robot_context_store is not None:
            try:
                robot_context_snapshot = robot_context_store.snapshot()
            except Exception:
                robot_context_snapshot = {}
        return {
            "interaction": dict(self._interaction_snapshot),
            "decay": dict(self._decay_snapshot),
            "entity_tracker": tracker_snapshot,
            "temporal_events": temporal_snapshot,
            "robot_context": robot_context_snapshot,
        }

    def _maybe_emit_slow_scene(
        self,
        result: LiveLoopResult,
        *,
        slow_scene: Any | None,
        scene: SceneCandidate,
        collected: CollectedFrames,
        decision_mode: Any | None,
        arbitration_outcome: str,
    ) -> None:
        if not self.enable_slow_scene or slow_scene is None:
            return

        slow_started_at = monotonic()
        scene_json = self._submit_or_query_slow_scene(
            slow_scene,
            scene,
            collected,
            decision_mode=decision_mode,
            arbitration_outcome=arbitration_outcome,
        )
        if scene_json is None:
            return

        result.slow_scene_results.append(scene_json)
        emit_stage_trace(
            self.telemetry,
            scene.trace_id,
            "slow_scene",
            payload={"scene_type": scene_json.scene_type, "confidence": scene_json.confidence},
            started_at=slow_started_at,
            ended_at=monotonic(),
        )

    @staticmethod
    def _behavior_to_scene_type(behavior_id: str) -> str:
        """Best-effort reverse mapping from behavior_id to scene_type for cooldown tracking."""
        _MAP = {
            "perform_greeting": "greeting_scene",
            "greeting_visual_only": "greeting_scene",
            "perform_attention": "attention_scene",
            "attention_minimal": "attention_scene",
            "perform_gesture_response": "gesture_bond_scene",
            "gesture_visual_only": "gesture_bond_scene",
            "perform_safety_alert": "safety_alert_scene",
            "perform_tracking": "ambient_tracking_scene",
        }
        return _MAP.get(behavior_id, behavior_id)


def _latest_target_id_from_events(
    events: list[Any],
    *,
    preferred_event_types: set[str],
) -> str | None:
    for event in reversed(events):
        if getattr(event, "event_type", None) not in preferred_event_types:
            continue
        payload = getattr(event, "payload", None)
        if not isinstance(payload, dict):
            continue
        raw = payload.get("target_id")
        if raw is None:
            continue
        value = str(raw).strip()
        if value:
            return value
    return None
