from __future__ import annotations

import logging
from dataclasses import dataclass, field
from time import monotonic
from typing import Any, Protocol, runtime_checkable


logger = logging.getLogger(__name__)


@dataclass
class StageTrace:
    """Trace record for a single runtime stage."""

    trace_id: str
    stage: str
    status: str = "ok"
    started_at: float = field(default_factory=monotonic)
    ended_at: float | None = None
    payload: dict[str, Any] = field(default_factory=dict)

    @property
    def duration_ms(self) -> float | None:
        if self.ended_at is None:
            return None
        return max(0.0, (self.ended_at - self.started_at) * 1000.0)


@runtime_checkable
class TelemetrySink(Protocol):
    """Interface for telemetry sinks used by live runtime."""

    def emit(self, trace: StageTrace) -> None:
        """Record a trace event."""
        ...


class NullTelemetrySink:
    """No-op telemetry sink for tests and early integration."""

    def emit(self, trace: StageTrace) -> None:  # noqa: D401 - protocol-style method
        return None


class InMemoryTelemetrySink:
    """Telemetry sink that stores traces in memory for analysis and validation."""

    def __init__(self) -> None:
        self.traces: list[StageTrace] = []

    def emit(self, trace: StageTrace) -> None:
        self.traces.append(trace)


class LoggingTelemetrySink:
    """Simple structured logging sink."""

    def __init__(
        self,
        logger_obj: logging.Logger | None = None,
        *,
        level: int = logging.DEBUG,
    ) -> None:
        self._logger = logger_obj or logger
        self._level = int(level)

    def emit(self, trace: StageTrace) -> None:
        if not self._logger.isEnabledFor(self._level):
            return
        self._logger.log(
            self._level,
            "stage=%s trace_id=%s status=%s duration_ms=%s payload=%s",
            trace.stage,
            trace.trace_id,
            trace.status,
            f"{trace.duration_ms:.2f}" if trace.duration_ms is not None else "n/a",
            trace.payload,
        )


def build_stage_trace(
    trace_id: str,
    stage: str,
    *,
    status: str = "ok",
    payload: dict[str, Any] | None = None,
    started_at: float | None = None,
    ended_at: float | None = None,
) -> StageTrace:
    """Create a stage trace with sensible defaults."""
    return StageTrace(
        trace_id=trace_id,
        stage=stage,
        status=status,
        started_at=started_at if started_at is not None else monotonic(),
        ended_at=ended_at,
        payload=payload or {},
    )


def emit_stage_trace(
    sink: TelemetrySink | None,
    trace_id: str,
    stage: str,
    *,
    status: str = "ok",
    payload: dict[str, Any] | None = None,
    started_at: float | None = None,
    ended_at: float | None = None,
) -> StageTrace:
    """Build and emit a stage trace if a sink is provided."""
    trace = build_stage_trace(
        trace_id,
        stage,
        status=status,
        payload=payload,
        started_at=started_at,
        ended_at=ended_at,
    )
    if sink is not None:
        sink.emit(trace)
    return trace
