from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor, TimeoutError as FutureTimeoutError
import logging
import os
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
import math
import shutil
import subprocess
import sys
import threading
from time import monotonic
from typing import Any, Deque, Union, Optional

try:
    import numpy as _np
except ImportError:  # pragma: no cover - optional dependency
    _np = None


logger = logging.getLogger(__name__)


@dataclass
class FramePacket:
    """Container for a single source sample."""

    source: str
    payload: Any
    timestamp_monotonic: float = field(default_factory=monotonic)
    frame_index: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class LiveMicrophoneProbe:
    source: FrameSource
    mode: str
    backend: str
    warning: str | None = None
    input_device_count: int = 0
    default_input_index: int | None = None
    selected_device: Any = None
    selected_device_name: str | None = None
    input_device_names: list[str] = field(default_factory=list)
    arecord_available: bool = False


class FrameSource(ABC):
    """Abstract source used by the live runtime."""

    def __init__(self, source_name: str) -> None:
        self.source_name = source_name
        self._opened = False

    @property
    def is_open(self) -> bool:
        return self._opened

    @abstractmethod
    def open(self) -> None:
        """Open the source."""

    @abstractmethod
    def read(self) -> FramePacket | None:
        """Read one packet from the source."""

    @abstractmethod
    def close(self) -> None:
        """Close the source."""

    def recover(self) -> bool:
        """Best-effort recovery hook used by the runtime on read/open failures."""
        try:
            self.close()
        except Exception:  # pragma: no cover - defensive cleanup
            logger.exception("source close failed during recovery: %s", self.source_name)
        try:
            self.open()
        except Exception:
            logger.exception("source recovery failed: %s", self.source_name)
            self._opened = False
            return False
        return True


class CameraSource(FrameSource):
    """OpenCV-backed camera source with lazy dependency loading."""

    _shared_executor: ThreadPoolExecutor | None = None
    _shared_executor_ref_count = 0
    _shared_executor_lock = threading.Lock()
    _shared_executor_workers = max(
        1,
        min(4, int(os.getenv("ROBOT_LIFE_CAMERA_READ_WORKERS", str(os.cpu_count() or 2)))),
    )

    def __init__(
        self,
        device_index: int = 0,
        *,
        source_name: str = "camera",
        backend: int | None = None,
        width: int | None = None,
        height: int | None = None,
        read_timeout_s: float = 0.12,
    ) -> None:
        super().__init__(source_name=source_name)
        self.device_index = device_index
        self.backend = backend
        self.width = width
        self.height = height
        self.read_timeout_s = max(0.02, float(read_timeout_s))
        self._capture: Any = None
        self._frame_index = 0
        self._read_failures = 0
        self.max_read_failures = 3
        self.recovery_cooldown_s = 1.5
        self._read_executor: ThreadPoolExecutor | None = None
        self._last_frame_at: float | None = None
        self._last_failure_at: float | None = None
        self._last_recovery_at: float | None = None
        self._recovery_count = 0
        self._total_failures = 0
        self._backend_name = "default"
        self._read_future: Future[tuple[bool, Any]] | None = None
        self.timeout_warning_interval_s = 2.0
        self._last_timeout_warning_at = 0.0

    @classmethod
    def _acquire_shared_executor(cls) -> ThreadPoolExecutor:
        with cls._shared_executor_lock:
            if cls._shared_executor is None:
                cls._shared_executor = ThreadPoolExecutor(
                    max_workers=cls._shared_executor_workers,
                    thread_name_prefix="camera-read",
                )
            cls._shared_executor_ref_count += 1
            return cls._shared_executor

    @classmethod
    def _release_shared_executor(cls, executor: ThreadPoolExecutor | None) -> None:
        if executor is None:
            return
        with cls._shared_executor_lock:
            if executor is not cls._shared_executor:
                return
            cls._shared_executor_ref_count = max(0, cls._shared_executor_ref_count - 1)
            if cls._shared_executor_ref_count == 0 and cls._shared_executor is not None:
                cls._shared_executor.shutdown(wait=False, cancel_futures=True)
                cls._shared_executor = None

    def _should_emit_timeout_warning(self) -> bool:
        now = monotonic()
        if (now - self._last_timeout_warning_at) >= self.timeout_warning_interval_s:
            self._last_timeout_warning_at = now
            return True
        return False

    def _open_capture(self, cv2: Any, backend: int | None) -> Any:
        if backend is None:
            return cv2.VideoCapture(self.device_index)
        return cv2.VideoCapture(self.device_index, backend)

    def open(self) -> None:
        try:
            import cv2
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("opencv-python is required for CameraSource") from exc

        preferred_backend = self.backend
        if preferred_backend is None and sys.platform == "darwin" and hasattr(cv2, "CAP_AVFOUNDATION"):
            preferred_backend = int(cv2.CAP_AVFOUNDATION)

        capture = self._open_capture(cv2, preferred_backend)
        if not capture.isOpened() and preferred_backend is not None:
            capture.release()
            capture = self._open_capture(cv2, None)

        if not capture.isOpened():
            raise RuntimeError(f"Failed to open camera device {self.device_index}")

        if self.width:
            capture.set(cv2.CAP_PROP_FRAME_WIDTH, float(self.width))
        if self.height:
            capture.set(cv2.CAP_PROP_FRAME_HEIGHT, float(self.height))
        if hasattr(cv2, "CAP_PROP_BUFFERSIZE"):
            try:
                capture.set(cv2.CAP_PROP_BUFFERSIZE, 1.0)
            except Exception:
                logger.debug("failed to set camera buffer size", exc_info=True)

        self._capture = capture
        self._opened = True
        self._read_failures = 0
        self._last_failure_at = None
        self._read_future = None
        if hasattr(capture, "getBackendName"):
            try:
                self._backend_name = str(capture.getBackendName() or self._backend_name)
            except Exception:
                self._backend_name = "default"
        if self._read_executor is None:
            self._read_executor = self._acquire_shared_executor()

    def _read_once(self) -> tuple[bool, Any]:
        if self._capture is None:
            return False, None

        executor = self._read_executor
        if executor is None:
            try:
                return self._capture.read()
            except Exception:
                return False, None

        if self._read_future is None:
            self._read_future = executor.submit(self._capture.read)
        future = self._read_future
        try:
            result = future.result(timeout=self.read_timeout_s)
            self._read_future = None
            return result
        except FutureTimeoutError:
            if self._should_emit_timeout_warning():
                logger.warning(
                    "camera read timed out after %.2fs (device=%s)",
                    self.read_timeout_s,
                    self.device_index,
                )
            return False, None
        except Exception:
            self._read_future = None
            return False, None

    def read(self) -> FramePacket | None:
        if not self._opened or self._capture is None:
            return None

        ok, frame = self._read_once()
        if not ok:
            self._read_failures += 1
            self._total_failures += 1
            self._last_failure_at = monotonic()
            if self._read_failures >= self.max_read_failures:
                can_recover = (
                    self._last_recovery_at is None
                    or (monotonic() - self._last_recovery_at) >= self.recovery_cooldown_s
                )
                if can_recover:
                    logger.warning(
                        "camera read failed %s times, attempting recovery (device=%s)",
                        self._read_failures,
                        self.device_index,
                    )
                    self._read_failures = 0
                    self._recovery_count += 1
                    self._last_recovery_at = monotonic()
                    self.recover()
            return None

        self._read_failures = 0
        self._frame_index += 1
        self._last_frame_at = monotonic()
        return FramePacket(
            source=self.source_name,
            payload=frame,
            frame_index=self._frame_index,
            metadata={
                "source_kind": "camera",
                "device_index": self.device_index,
                "camera_backend": self._backend_name,
            },
        )

    def close(self) -> None:
        if self._read_future is not None:
            self._read_future.cancel()
            self._read_future = None
        if self._capture is not None:
            self._capture.release()
            self._capture = None
        if self._read_executor is not None:
            self._release_shared_executor(self._read_executor)
            self._read_executor = None
        self._opened = False

    def snapshot_health(self) -> dict[str, Any]:
        return {
            "device_index": self.device_index,
            "read_timeout_s": self.read_timeout_s,
            "read_failures": self._read_failures,
            "total_failures": self._total_failures,
            "recovery_count": self._recovery_count,
            "last_frame_at": self._last_frame_at,
            "last_failure_at": self._last_failure_at,
            "last_recovery_at": self._last_recovery_at,
            "backend": self._backend_name,
        }


class SyntheticCameraSource(FrameSource):
    """Synthetic frame source for local mock-driver development."""

    def __init__(self, *, source_name: str = "camera") -> None:
        super().__init__(source_name=source_name)
        self._frame_index = 0

    def open(self) -> None:
        self._opened = True

    def read(self) -> FramePacket | None:
        if not self._opened:
            return None
        self._frame_index += 1
        return FramePacket(
            source=self.source_name,
            payload={"synthetic_frame": True, "frame_index": self._frame_index},
            frame_index=self._frame_index,
        )

    def close(self) -> None:
        self._opened = False


class SyntheticMicrophoneSource(FrameSource):
    """Synthetic microphone source for local mock-driver development."""

    def __init__(self, *, source_name: str = "microphone") -> None:
        super().__init__(source_name=source_name)
        self._frame_index = 0

    def open(self) -> None:
        self._opened = True

    def read(self) -> FramePacket | None:
        if not self._opened:
            return None
        self._frame_index += 1
        return FramePacket(
            source=self.source_name,
            payload={"synthetic_audio": True, "frame_index": self._frame_index},
            frame_index=self._frame_index,
        )

    def close(self) -> None:
        self._opened = False


class MicrophoneSource(FrameSource):
    """Microphone abstraction that can be backed by a future hardware adapter."""

    def __init__(self, *, source_name: str = "microphone") -> None:
        super().__init__(source_name=source_name)
        self._buffer: Deque[FramePacket] = deque()
        self._frame_index = 0

    def open(self) -> None:
        self._opened = True

    def push(self, payload: Any, metadata: dict[str, Any] | None = None) -> None:
        """Inject a sample into the source buffer."""
        self._frame_index += 1
        self._buffer.append(
            FramePacket(
                source=self.source_name,
                payload=payload,
                frame_index=self._frame_index,
                metadata=metadata or {},
            )
        )

    def read(self) -> FramePacket | None:
        if not self._opened:
            return None
        if not self._buffer:
            return None
        return self._buffer.popleft()

    def close(self) -> None:
        self._buffer.clear()
        self._opened = False

    def snapshot_health(self) -> dict[str, Any]:
        return {
            "source_kind": "microphone",
            "mode": "fallback",
            "backend": "silent",
            "status": "silent_fallback",
            "buffer_depth": len(self._buffer),
        }


class SoundDeviceMicrophoneSource(FrameSource):
    """Real microphone source backed by sounddevice InputStream."""

    def __init__(
        self,
        *,
        source_name: str = "microphone",
        device: Any = None,
        sample_rate: int = 16_000,
        channels: int = 1,
        blocksize: int = 1024,
        max_buffer_packets: int = 32,
    ) -> None:
        super().__init__(source_name=source_name)
        self.device = device
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.blocksize = int(blocksize)
        self._frame_index = 0
        self._stream: Any = None
        self._buffer: Deque[FramePacket] = deque(maxlen=max(1, int(max_buffer_packets)))
        self._dropped_packets = 0
        self._last_rms: float | None = None
        self._last_db: float | None = None
        self._last_packet_at: float | None = None

    @property
    def max_buffer_packets(self) -> int:
        return self._buffer.maxlen or 1

    def _enqueue_packet(self, packet: FramePacket) -> None:
        if len(self._buffer) >= self.max_buffer_packets:
            self._dropped_packets += 1
            self._buffer.popleft()
        self._buffer.append(packet)

    def open(self) -> None:
        try:
            import sounddevice as sd  # type: ignore
        except Exception as exc:
            raise RuntimeError("sounddevice is required for SoundDeviceMicrophoneSource") from exc

        def _callback(indata, frames, time_info, status) -> None:
            self._frame_index += 1
            payload = indata.copy()
            metadata = {"frames": int(frames), "status": str(status) if status else ""}
            rms, db = self._compute_level(payload)
            if rms is not None:
                self._last_rms = rms
                self._last_db = db
                self._last_packet_at = monotonic()
            self._enqueue_packet(
                FramePacket(
                    source=self.source_name,
                    payload=payload,
                    frame_index=self._frame_index,
                    metadata=metadata,
                )
            )

        self._stream = sd.InputStream(
            device=self.device,
            samplerate=self.sample_rate,
            channels=self.channels,
            blocksize=self.blocksize,
            dtype="float32",
            callback=_callback,
        )
        self._stream.start()
        self._opened = True

    def read(self) -> FramePacket | None:
        if not self._opened:
            return None
        if not self._buffer:
            return None
        return self._buffer.popleft()

    def close(self) -> None:
        stream = self._stream
        self._stream = None
        if stream is not None:
            try:
                stream.stop()
            except Exception:
                logger.warning("failed to stop microphone stream %s", self.source_name)
            try:
                stream.close()
            except Exception:
                logger.warning("failed to close microphone stream %s", self.source_name)
        self._buffer.clear()
        self._opened = False
        self._last_rms = None
        self._last_db = None
        self._last_packet_at = None

    @staticmethod
    def _compute_level(samples: Any) -> tuple[float | None, float | None]:
        try:
            if _np is not None:
                array = _np.asarray(samples, dtype=_np.float64).reshape(-1)
                if array.size == 0:
                    return None, None
                rms = float(_np.sqrt(_np.mean(_np.square(array))))
                db = float(20.0 * math.log10(max(rms, 1e-12)))
                return rms, db
            values = [float(item) for item in samples]
            if not values:
                return None, None
            rms = math.sqrt(sum(item * item for item in values) / len(values))
            db = 20.0 * math.log10(max(rms, 1e-12))
            return float(rms), float(db)
        except Exception:
            return None, None

    def snapshot_health(self) -> dict[str, Any]:
        return {
            "source_kind": "sounddevice",
            "mode": "real",
            "backend": "sounddevice",
            "status": "ready" if self._opened else "closed",
            "buffer_depth": len(self._buffer),
            "max_buffer_packets": self.max_buffer_packets,
            "dropped_packets": self._dropped_packets,
            "device": None if self.device is None else str(self.device),
            "audio_rms": None if self._last_rms is None else round(float(self._last_rms), 6),
            "audio_db": None if self._last_db is None else round(float(self._last_db), 2),
            "last_packet_age_ms": (
                None if self._last_packet_at is None else round((monotonic() - self._last_packet_at) * 1000.0, 2)
            ),
        }


class ArecordMicrophoneSource(FrameSource):
    """Real microphone source backed by `arecord` and ALSA/PulseAudio."""

    def __init__(
        self,
        *,
        source_name: str = "microphone",
        device: str = "default",
        sample_rate: int = 16_000,
        channels: int = 1,
        chunk_frames: int = 1024,
        max_buffer_packets: int = 32,
    ) -> None:
        super().__init__(source_name=source_name)
        self.device = str(device)
        self.sample_rate = int(sample_rate)
        self.channels = max(1, int(channels))
        self.chunk_frames = max(64, int(chunk_frames))
        self._frame_index = 0
        self._buffer: Deque[FramePacket] = deque(maxlen=max(1, int(max_buffer_packets)))
        self._process: subprocess.Popen[bytes] | None = None
        self._reader_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    def open(self) -> None:
        if shutil.which("arecord") is None:
            raise RuntimeError("arecord is required for ArecordMicrophoneSource")

        if self._opened:
            return

        cmd = [
            "arecord",
            "-q",
            "-D",
            self.device,
            "-f",
            "S16_LE",
            "-r",
            str(self.sample_rate),
            "-c",
            str(self.channels),
            "-t",
            "raw",
        ]
        self._stop_event.clear()
        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if self._process.stdout is None:
            raise RuntimeError("arecord stdout pipe unavailable")
        self._opened = True
        self._reader_thread = threading.Thread(target=self._reader_loop, name="arecord-mic", daemon=True)
        self._reader_thread.start()

    def _reader_loop(self) -> None:
        process = self._process
        if process is None or process.stdout is None:
            return

        bytes_per_sample = 2
        frame_bytes = self.chunk_frames * self.channels * bytes_per_sample
        while not self._stop_event.is_set():
            try:
                raw = process.stdout.read(frame_bytes)
            except Exception:
                break
            if not raw:
                break
            audio = self._decode_audio(raw)
            if audio is None:
                continue
            self._frame_index += 1
            self._buffer.append(
                FramePacket(
                    source=self.source_name,
                    payload={
                        "audio": audio,
                        "sample_rate": self.sample_rate,
                        "channels": self.channels,
                        "device": self.device,
                        "source_kind": "arecord",
                    },
                    frame_index=self._frame_index,
                    metadata={"raw_bytes": len(raw)},
                )
            )

    def _decode_audio(self, raw: bytes) -> Any | None:
        if not raw:
            return None
        if _np is None:
            return None
        try:
            audio = _np.frombuffer(raw, dtype=_np.int16).astype(_np.float32)
            if audio.size == 0:
                return None
            audio = audio / 32768.0
            return audio.reshape(-1)
        except Exception:
            return None

    def read(self) -> FramePacket | None:
        if not self._opened:
            return None
        if not self._buffer:
            return None
        return self._buffer.popleft()

    def close(self) -> None:
        self._stop_event.set()
        process = self._process
        self._process = None
        if process is not None:
            try:
                process.terminate()
            except Exception:
                logger.warning("failed to terminate arecord process %s", self.source_name)
            try:
                process.wait(timeout=1.0)
            except Exception:
                try:
                    process.kill()
                except Exception:
                    logger.warning("failed to kill arecord process %s", self.source_name)
        thread = self._reader_thread
        self._reader_thread = None
        if thread is not None and thread.is_alive():
            thread.join(timeout=1.0)
        self._buffer.clear()
        self._opened = False

    def snapshot_health(self) -> dict[str, Any]:
        return {
            "source_kind": "arecord",
            "mode": "real",
            "backend": "arecord",
            "status": "ready" if self._opened else "closed",
            "buffer_depth": len(self._buffer),
            "device": self.device,
        }


@dataclass
class SourceBundle:
    """Convenience wrapper for a set of sources."""

    camera: FrameSource | None = None
    microphone: FrameSource | None = None

    def open_all(self) -> None:
        for source in self.iter_sources():
            try:
                source.open()
            except Exception as exc:
                logger.warning("failed to open source %s: %s", source.source_name, exc)

    def close_all(self) -> None:
        for source in self.iter_sources():
            try:
                source.close()
            except Exception as exc:
                logger.warning("failed to close source %s: %s", source.source_name, exc)

    def iter_sources(self) -> list[FrameSource]:
        sources: list[FrameSource] = []
        if self.camera is not None:
            sources.append(self.camera)
        if self.microphone is not None:
            sources.append(self.microphone)
        return sources

    def read_packets(self) -> dict[str, FramePacket]:
        packets: dict[str, FramePacket] = {}
        for source in self.iter_sources():
            try:
                packet = source.read()
            except Exception as exc:
                logger.warning("source read failed for %s: %s", source.source_name, exc)
                source.recover()
                continue
            if packet is not None:
                packets[source.source_name] = packet
        return packets

    def read_payloads(self) -> dict[str, Any]:
        return {name: packet.payload for name, packet in self.read_packets().items()}


def probe_live_microphone_source(
    *,
    arecord_device: str = "default",
    preferred_device: Any = None,
) -> LiveMicrophoneProbe:
    """Probe microphone availability and choose the best source for this machine."""
    reason: str | None = None
    default_input_index: int | None = None
    input_device_count = 0
    selected_device: Any = None
    selected_device_name: str | None = None
    input_device_names: list[str] = []
    arecord_available = shutil.which("arecord") is not None
    try:
        import sounddevice  # noqa: F401

        try:
            import sounddevice as sd  # type: ignore

            devices = sd.query_devices()
        except Exception as exc:
            reason = f"sounddevice 不可用 ({exc}); "
        else:
            requested_device: Any = preferred_device
            if requested_device in {None, ""}:
                requested_device = os.environ.get("ROBOT_LIFE_MIC_DEVICE")
            if isinstance(requested_device, str):
                requested_device = requested_device.strip()
                if requested_device.lower() in {"", "auto", "default"}:
                    requested_device = None

            default_config = getattr(sd, "default", None)
            raw_default_device = getattr(default_config, "device", default_config)
            if isinstance(raw_default_device, (list, tuple)) and raw_default_device:
                try:
                    default_input_index = int(raw_default_device[0])
                except (TypeError, ValueError):
                    default_input_index = None
            elif isinstance(raw_default_device, int):
                default_input_index = raw_default_device

            usable_input_index: int | None = None
            try:
                normalized_devices = list(devices)
            except Exception:
                normalized_devices = []
            input_device_names = [
                str(info.get("name", "")).strip()
                for info in normalized_devices
                if isinstance(info, dict) and int(info.get("max_input_channels", 0)) > 0
            ]
            input_device_count = sum(
                1
                for info in normalized_devices
                if isinstance(info, dict) and int(info.get("max_input_channels", 0)) > 0
            )

            if requested_device is not None:
                requested_index: int | None = None
                if isinstance(requested_device, int):
                    requested_index = requested_device
                elif isinstance(requested_device, str):
                    try:
                        requested_index = int(requested_device)
                    except (TypeError, ValueError):
                        requested_index = None

                if requested_index is not None and requested_index >= 0:
                    try:
                        requested_info = sd.query_devices(requested_index, "input")
                    except Exception:
                        requested_info = None
                    if isinstance(requested_info, dict) and int(requested_info.get("max_input_channels", 0)) > 0:
                        usable_input_index = requested_index
                    else:
                        reason = f"指定麦克风设备 {requested_device} 不可用; "
                elif isinstance(requested_device, str):
                    requested_text = requested_device.lower()
                    for index, info in enumerate(normalized_devices):
                        if not isinstance(info, dict):
                            continue
                        if int(info.get("max_input_channels", 0)) <= 0:
                            continue
                        name = str(info.get("name", "")).lower()
                        if requested_text in name:
                            usable_input_index = index
                            break
                    if usable_input_index is None:
                        reason = f"未找到匹配麦克风设备名: {requested_device}; "

            if usable_input_index is None and default_input_index is not None and default_input_index >= 0:
                try:
                    default_info = sd.query_devices(default_input_index, "input")
                except Exception:
                    default_info = None
                if isinstance(default_info, dict) and int(default_info.get("max_input_channels", 0)) > 0:
                    usable_input_index = default_input_index

            if usable_input_index is None:
                for index, info in enumerate(normalized_devices):
                    if isinstance(info, dict) and int(info.get("max_input_channels", 0)) > 0:
                        usable_input_index = index
                        break

            if usable_input_index is not None:
                selected_device = usable_input_index
                try:
                    selected_info = sd.query_devices(usable_input_index, "input")
                except Exception:
                    selected_info = None
                if isinstance(selected_info, dict):
                    selected_device_name = str(selected_info.get("name", "")).strip() or None
                return LiveMicrophoneProbe(
                    source=SoundDeviceMicrophoneSource(device=usable_input_index),
                    mode="real",
                    backend="sounddevice",
                    warning=None,
                    input_device_count=input_device_count,
                    default_input_index=default_input_index,
                    selected_device=selected_device,
                    selected_device_name=selected_device_name,
                    input_device_names=input_device_names,
                    arecord_available=arecord_available,
                )
            reason = "sounddevice 未发现可用输入设备; "
    except Exception as exc:
        reason = f"sounddevice 不可用 ({exc}); "

    if arecord_available:
        return LiveMicrophoneProbe(
            source=ArecordMicrophoneSource(device=arecord_device),
            mode="real",
            backend="arecord",
            warning=f"{reason}已切换到 arecord 真实麦克风模式",
            input_device_count=input_device_count,
            default_input_index=default_input_index,
            selected_device=arecord_device,
            selected_device_name=f"arecord:{arecord_device}",
            input_device_names=input_device_names,
            arecord_available=True,
        )

    if sys.platform == "darwin":
        fallback_warning = (
            f"{reason}当前已切换到静音麦克风模式；"
            "请检查“系统设置 -> 隐私与安全性 -> 麦克风”以及系统默认输入设备。"
        )
    else:
        fallback_warning = f"{reason}未找到 arecord，已切换到静音麦克风模式"
    return LiveMicrophoneProbe(
        source=MicrophoneSource(),
        mode="fallback",
        backend="silent",
        warning=fallback_warning,
        input_device_count=input_device_count,
        default_input_index=default_input_index,
        selected_device_name=selected_device_name,
        input_device_names=input_device_names,
        arecord_available=arecord_available,
    )


def build_live_microphone_source(
    *,
    arecord_device: str = "default",
    preferred_device: Any = None,
) -> tuple[FrameSource, str | None]:
    """Choose the best available live microphone source for this machine."""
    probe = probe_live_microphone_source(arecord_device=arecord_device, preferred_device=preferred_device)
    return probe.source, probe.warning
