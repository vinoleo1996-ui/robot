from __future__ import annotations

from dataclasses import dataclass, field
from time import time

from robot_life.behavior.behavior_registry import BehaviorTemplate
from robot_life.behavior.bt_nodes import NodeResult, run_node
from robot_life.common.schemas import DecisionMode, ExecutionResult, new_id


@dataclass
class ActiveBehavior:
    execution_id: str
    trace_id: str
    behavior_id: str
    grant_id: str
    started_at: float
    degraded: bool
    resumable: bool
    mode: DecisionMode
    nodes: list[str]
    next_node_index: int = 0
    completed_nodes: list[NodeResult] = field(default_factory=list)
    status: str = "running"


class BehaviorRuntime:
    """Minimal synchronous BT runtime with interrupt bookkeeping."""

    def __init__(self):
        self._active: ActiveBehavior | None = None

    def start(
        self,
        trace_id: str,
        template: BehaviorTemplate,
        grant_id: str,
        degraded: bool,
        mode: DecisionMode,
        started_at: float | None = None,
    ) -> ActiveBehavior:
        active = ActiveBehavior(
            execution_id=new_id(),
            trace_id=trace_id,
            behavior_id=template.behavior_id,
            grant_id=grant_id,
            started_at=started_at if started_at is not None else time(),
            degraded=degraded,
            resumable=template.resumable,
            mode=mode,
            nodes=list(template.nodes),
        )
        self._active = active
        return active

    def tick(self, max_nodes: int = 1) -> ExecutionResult | None:
        """Execute at most `max_nodes` BT nodes for the active behavior."""
        active = self._active
        if active is None:
            return None

        budget = max(1, int(max_nodes))
        processed = 0
        while processed < budget and active.next_node_index < len(active.nodes):
            node_name = active.nodes[active.next_node_index]
            node_result = run_node(node_name=node_name, behavior_id=active.behavior_id, degraded=active.degraded)
            active.completed_nodes.append(node_result)
            active.next_node_index += 1
            processed += 1
            if node_result.status != "success":
                active.status = "failed"
                return self._finish_active()

        if active.next_node_index >= len(active.nodes):
            active.status = "finished"
            return self._finish_active()
        active.status = "running"
        return None

    def run_to_completion(
        self,
        trace_id: str,
        template: BehaviorTemplate,
        grant_id: str,
        degraded: bool,
        mode: DecisionMode,
        started_at: float | None = None,
    ) -> ExecutionResult:
        self.start(
            trace_id=trace_id,
            template=template,
            grant_id=grant_id,
            degraded=degraded,
            mode=mode,
            started_at=started_at,
        )
        while True:
            finished = self.tick(max_nodes=len(template.nodes) + 1)
            if finished is not None:
                return finished

    def _finish_active(self) -> ExecutionResult:
        active = self._active
        if active is None:
            raise RuntimeError("cannot finish inactive behavior")
        finished = ExecutionResult(
            execution_id=active.execution_id,
            trace_id=active.trace_id,
            behavior_id=active.behavior_id,
            status=active.status,
            interrupted=False,
            degraded=active.degraded,
            started_at=active.started_at,
            ended_at=time(),
        )
        self._active = None
        return finished

    def interrupt(self, mode: DecisionMode = DecisionMode.SOFT_INTERRUPT) -> ExecutionResult | None:
        """Interrupt current behavior if one is actively tracked."""
        if self._active is None:
            return None

        active = self._active
        active.status = "interrupted"
        self._active = None
        return ExecutionResult(
            execution_id=active.execution_id,
            trace_id=active.trace_id,
            behavior_id=active.behavior_id,
            status="interrupted",
            interrupted=True,
            degraded=active.degraded,
            started_at=active.started_at,
            ended_at=time(),
        )

    def active_behavior(self) -> ActiveBehavior | None:
        return self._active
